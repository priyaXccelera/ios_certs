import React from 'react';
import { Pressable, StyleSheet, Text, View, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type HeaderBarProps = {
  title: string;
  onMenuPress: () => void;
};

export function HeaderBar({ title, onMenuPress }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <Pressable
        onPress={onMenuPress}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
        style={({ pressed }) => [styles.menuButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        hitSlop={s(2)}
      >
        <MaterialIcons name="menu" size={24} color={colors.textPrimary} />
      </Pressable>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.menuSpacer} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  menuButton: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.7,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 16 * 1.2,
    letterSpacing: 1.2,
    color: colors.textPrimary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
  menuSpacer: {
    width: s(10),
  },
});
