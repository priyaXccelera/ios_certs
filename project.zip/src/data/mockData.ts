import { Appointment, DayKey, Location, ScheduleOverride, Service, StaffMember, WeeklySchedule, WaitlistEntry } from '../types';

export const locations: Location[] = [
  { id: 'loc-1', name: 'Downtown Studio', city: 'Chicago', timezone: 'America/Chicago', address: '100 Lake Street' },
  { id: 'loc-2', name: 'Westside Clinic', city: 'Los Angeles', timezone: 'America/Los_Angeles', address: '420 Sunset Avenue' },
  { id: 'loc-3', name: 'North Spa', city: 'New York', timezone: 'America/New_York', address: '78 Park Place' },
];

export const services: Service[] = [
  { id: 'svc-1', name: 'Haircut', durationMinutes: 45, priceCents: 4999, staffIds: ['staff-1', 'staff-2', 'staff-4'] },
  { id: 'svc-2', name: 'Massage Therapy', durationMinutes: 60, priceCents: 8999, staffIds: ['staff-3', 'staff-5'] },
  { id: 'svc-3', name: 'Consultation', durationMinutes: 30, priceCents: 1999, staffIds: ['staff-1', 'staff-3', 'staff-6'] },
  { id: 'svc-4', name: 'Color Treatment', durationMinutes: 90, priceCents: 12999, staffIds: ['staff-2', 'staff-4'] },
];

export const staffMembers: StaffMember[] = [
  { id: 'staff-1', name: 'Avery Morgan', role: 'Stylist', locationId: 'loc-1', serviceIds: ['svc-1', 'svc-3'] },
  { id: 'staff-2', name: 'Jordan Lee', role: 'Senior Stylist', locationId: 'loc-1', serviceIds: ['svc-1', 'svc-4'] },
  { id: 'staff-3', name: 'Sam Rivera', role: 'Therapist', locationId: 'loc-2', serviceIds: ['svc-2', 'svc-3'] },
  { id: 'staff-4', name: 'Casey Chen', role: 'Color Specialist', locationId: 'loc-2', serviceIds: ['svc-1', 'svc-4'] },
  { id: 'staff-5', name: 'Riley Patel', role: 'Massage Therapist', locationId: 'loc-3', serviceIds: ['svc-2'] },
  { id: 'staff-6', name: 'Taylor Brooks', role: 'Clinician', locationId: 'loc-3', serviceIds: ['svc-3'] },
];

const weekDays: DayKey[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const weekdayBlocks = [{ start: '09:00', end: '12:00' }, { start: '13:00', end: '17:00' }];

export const weeklySchedules: WeeklySchedule[] = staffMembers.map((staff) => ({
  staffId: staff.id,
  days: weekDays.reduce((acc, day) => ({ ...acc, [day]: day === 'Saturday' ? [{ start: '10:00', end: '14:00' }] : day === 'Sunday' ? [] : weekdayBlocks }), {} as Record<DayKey, { start: string; end: string }[]>),
}));

export const scheduleOverrides: ScheduleOverride[] = [
  { id: 'ovr-1', staffId: 'staff-2', date: '2026-07-28', type: 'customHours', blocks: [{ start: '09:00', end: '13:00' }], note: 'Leaves early' },
  { id: 'ovr-2', staffId: 'staff-5', date: '2026-07-29', type: 'dayOff', blocks: [], note: 'Vacation day' },
];

export const appointments: Appointment[] = [
  { id: 'apt-1', customerName: 'Mia Carter', customerEmail: 'mia@example.com', locationId: 'loc-1', serviceId: 'svc-1', staffId: 'staff-1', startIso: '2026-07-27T15:00:00.000Z', endIso: '2026-07-27T15:45:00.000Z', status: 'confirmed', priceCents: 4999 },
  { id: 'apt-2', customerName: 'Noah Smith', customerEmail: 'noah@example.com', locationId: 'loc-1', serviceId: 'svc-4', staffId: 'staff-2', startIso: '2026-07-28T16:00:00.000Z', endIso: '2026-07-28T17:30:00.000Z', status: 'confirmed', priceCents: 12999 },
  { id: 'apt-3', customerName: 'Olivia King', customerEmail: 'olivia@example.com', locationId: 'loc-2', serviceId: 'svc-2', staffId: 'staff-3', startIso: '2026-07-22T18:00:00.000Z', endIso: '2026-07-22T19:00:00.000Z', status: 'completed', priceCents: 8999 },
  { id: 'apt-4', customerName: 'Liam Brown', customerEmail: 'liam@example.com', locationId: 'loc-2', serviceId: 'svc-1', staffId: 'staff-4', startIso: '2026-07-21T20:00:00.000Z', endIso: '2026-07-21T20:45:00.000Z', status: 'noShow', priceCents: 4999 },
  { id: 'apt-5', customerName: 'Emma Davis', customerEmail: 'emma@example.com', locationId: 'loc-3', serviceId: 'svc-2', staffId: 'staff-5', startIso: '2026-07-30T14:00:00.000Z', endIso: '2026-07-30T15:00:00.000Z', status: 'confirmed', priceCents: 8999 },
  { id: 'apt-6', customerName: 'Ethan Wilson', customerEmail: 'ethan@example.com', locationId: 'loc-3', serviceId: 'svc-3', staffId: 'staff-6', startIso: '2026-07-23T15:30:00.000Z', endIso: '2026-07-23T16:00:00.000Z', status: 'completed', priceCents: 1999 },
  { id: 'apt-7', customerName: 'Sophia Moore', customerEmail: 'sophia@example.com', locationId: 'loc-1', serviceId: 'svc-1', staffId: 'staff-1', startIso: '2026-08-01T14:00:00.000Z', endIso: '2026-08-01T14:45:00.000Z', status: 'confirmed', priceCents: 4999 },
  { id: 'apt-8', customerName: 'Lucas Taylor', customerEmail: 'lucas@example.com', locationId: 'loc-2', serviceId: 'svc-3', staffId: 'staff-3', startIso: '2026-07-20T16:00:00.000Z', endIso: '2026-07-20T16:30:00.000Z', status: 'cancelled', priceCents: 1999 },
  { id: 'apt-9', customerName: 'Ava Anderson', customerEmail: 'ava@example.com', locationId: 'loc-1', serviceId: 'svc-4', staffId: 'staff-2', startIso: '2026-08-02T17:00:00.000Z', endIso: '2026-08-02T18:30:00.000Z', status: 'confirmed', priceCents: 12999 },
  { id: 'apt-10', customerName: 'Henry Martin', customerEmail: 'henry@example.com', locationId: 'loc-3', serviceId: 'svc-2', staffId: 'staff-5', startIso: '2026-08-03T18:00:00.000Z', endIso: '2026-08-03T19:00:00.000Z', status: 'confirmed', priceCents: 8999 },
];

export const waitlistEntries: WaitlistEntry[] = [
  { id: 'wait-1', customerName: 'Grace Hall', customerEmail: 'grace@example.com', locationId: 'loc-1', serviceId: 'svc-4', staffId: 'staff-2', date: '2026-07-28', createdAtIso: '2026-07-22T12:00:00.000Z', notified: false },
  { id: 'wait-2', customerName: 'Jack Young', customerEmail: 'jack@example.com', locationId: 'loc-2', serviceId: 'svc-2', date: '2026-07-31', createdAtIso: '2026-07-22T13:00:00.000Z', notified: false },
  { id: 'wait-3', customerName: 'Ella Green', customerEmail: 'ella@example.com', locationId: 'loc-3', serviceId: 'svc-2', staffId: 'staff-5', date: '2026-07-30', createdAtIso: '2026-07-21T11:00:00.000Z', notified: true },
];

export const formatMoney = (priceCents: number) => `$${(priceCents / 100).toFixed(2)}`;
