import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { RootStackParamList } from '../navigation';
import { DayKey, ScheduleOverride } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const days: DayKey[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function StaffHoursScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'StaffHours'>>();
  const route = useRoute<RouteProp<RootStackParamList, 'StaffHours'>>();
  const { staffMembers, weeklySchedules, updateWeeklySchedule, scheduleOverrides, addScheduleOverride } = useAppData();
  const [staffId, setStaffId] = useState(route.params?.staffId ?? staffMembers[0]?.id ?? '');
  const [day, setDay] = useState<DayKey>('Monday');
  const [blocks, setBlocks] = useState('09:00-12:00, 13:00-17:00');
  const [overrideDate, setOverrideDate] = useState(new Date().toISOString().slice(0, 10));
  const [overrideType, setOverrideType] = useState<'dayOff' | 'customHours'>('customHours');
  const [overrideBlocks, setOverrideBlocks] = useState('09:00-13:00');
  const [note, setNote] = useState('Different hours');
  const schedule = weeklySchedules.find((item) => item.staffId === staffId);
  const parseBlocks = (text: string) => text.split(',').map((part) => part.trim()).filter(Boolean).map((part) => { const [start, end] = part.split('-').map((value) => value.trim()); return { start: start || '09:00', end: end || '17:00' }; });
  const saveWeekly = () => {
    if (!schedule) return;
    updateWeeklySchedule({ ...schedule, days: { ...schedule.days, [day]: parseBlocks(blocks) } });
  };
  const saveOverride = () => {
    const override: ScheduleOverride = { id: `ovr-${Date.now()}`, staffId, date: overrideDate, type: overrideType, blocks: overrideType === 'dayOff' ? [] : parseBlocks(overrideBlocks), note: note.trim() || 'Override' };
    addScheduleOverride(override);
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Staff hours" subtitle="Weekly blocks and date overrides" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <AppText variant="label">STAFF MEMBER</AppText><View style={styles.wrap}>{staffMembers.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => setStaffId(item.id)} />)}</View>
          <View style={styles.card}>
            <AppText variant="subtitle">Normal weekly schedule</AppText>
            <View style={styles.wrap}>{days.map((item) => <Chip key={item} label={item.slice(0, 3)} selected={day === item} onPress={() => { setDay(item); const current = schedule?.days[item] ?? []; setBlocks(current.map((block) => `${block.start}-${block.end}`).join(', ')); }} />)}</View>
            <TextInput value={blocks} onChangeText={setBlocks} placeholder="09:00-12:00, 13:00-17:00" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <PrimaryButton label="Save weekly blocks" onPress={saveWeekly} />
          </View>
          <View style={styles.card}>
            <AppText variant="subtitle">Day-specific override</AppText>
            <TextInput value={overrideDate} onChangeText={setOverrideDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <View style={styles.wrap}><Chip label="Custom hours" selected={overrideType === 'customHours'} onPress={() => setOverrideType('customHours')} /><Chip label="Full day off" selected={overrideType === 'dayOff'} onPress={() => setOverrideType('dayOff')} /></View>
            <TextInput value={overrideBlocks} onChangeText={setOverrideBlocks} placeholder="09:00-13:00" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <TextInput value={note} onChangeText={setNote} placeholder="Note" placeholderTextColor={colors.textDisabled} autoCapitalize="sentences" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <PrimaryButton label="Save override" onPress={saveOverride} variant="secondary" />
          </View>
          <AppText variant="subtitle" style={styles.section}>Existing overrides</AppText>
          {scheduleOverrides.filter((item) => item.staffId === staffId).map((item) => <View key={item.id} style={styles.overrideRow}><AppText variant="body" style={styles.overrideTitle}>{item.date} · {item.type}</AppText><AppText variant="caption">{item.note} · {item.blocks.map((block) => `${block.start}-${block.end}`).join(', ') || 'No hours'}</AppText></View>)}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginTop: s(2), marginBottom: s(3) },
  card: { backgroundColor: colors.surface, borderRadius: s(3), padding: s(4), marginBottom: s(4), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  section: { marginBottom: s(3) },
  overrideRow: { backgroundColor: colors.surface, borderRadius: s(3), padding: s(3), marginBottom: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  overrideTitle: { fontFamily: 'Inter-SemiBold', fontWeight: '600' },
});
