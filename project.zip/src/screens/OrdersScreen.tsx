import React, { useState } from 'react';
import { Alert, FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { orders as mockOrders, products } from '../data/mockData';
import { Order } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const steps = ['Processing', 'Packed', 'Shipped', 'Delivered'];

export default function OrdersScreen() {
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [expandedId, setExpandedId] = useState<string | null>(orders[0]?.id ?? null);

  const buyAgain = (order: Order) => {
    setOrders((prev) => [{ ...order, id: `o${Date.now()}`, date: new Date().toISOString().slice(0, 10), status: 'Processing' }, ...prev]);
    Alert.alert('Buy Again', 'A new mock order was created from your history.');
  };

  const renderOrder = ({ item }: { item: Order }) => {
    const orderProducts = item.productIds.map((id) => products.find((product) => product.id === id) ?? products[0]);
    const activeStep = steps.indexOf(item.status);
    const expanded = expandedId === item.id;
    return (
      <View style={styles.card}>
        <Pressable onPress={() => setExpandedId(expanded ? null : item.id)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.pressed]} />
        <View pointerEvents="none" style={styles.headerRow}>
          <View>
            <Text style={styles.orderId}>{item.id}</Text>
            <Text style={styles.meta}>{item.date} · {orderProducts.length} item bundle</Text>
          </View>
          <Text style={styles.total}>${item.total}</Text>
        </View>
        <View pointerEvents="none" style={styles.progressRow}>
          {steps.map((step, index) => (
            <View key={step} style={styles.stepWrap}>
              <View style={[styles.stepDot, index <= activeStep && styles.stepActive]} />
              <Text style={[styles.stepText, index <= activeStep && styles.stepTextActive]}>{step}</Text>
            </View>
          ))}
        </View>
        {expanded ? (
          <View style={styles.details}>
            {orderProducts.map((product) => <Text key={`${item.id}-${product.id}`} style={styles.productLine}>• {product.name}</Text>)}
            <Text style={styles.summaryLine}>Deliver to {item.address}</Text>
            <Text style={styles.summaryLine}>Paid with {item.paymentMethod}</Text>
          </View>
        ) : null}
        <Pressable onPress={() => buyAgain(item)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.buyAgain, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Ionicons name="refresh" size={s(4)} color={colors.textInverse} />
          <Text style={styles.buyAgainText}>Buy Again</Text>
        </Pressable>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Orders" subtitle="Mock purchase history" />
      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        renderItem={renderOrder}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}) },
  listContent: { paddingHorizontal: s(4), paddingBottom: s(8) },
  card: { minHeight: s(54), borderRadius: s(4), backgroundColor: colors.card, overflow: 'hidden', padding: s(4), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 3 }, default: {} }) },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingRight: s(2) },
  orderId: { fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  meta: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  total: { fontFamily: 'Inter-Bold', fontSize: s(6), lineHeight: s(6) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: s(5), marginBottom: s(4) },
  stepWrap: { flex: 1, alignItems: 'center' },
  stepDot: { width: s(4), height: s(4), borderRadius: s(2), backgroundColor: colors.border, marginBottom: s(2) },
  stepActive: { backgroundColor: colors.success },
  stepText: { fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textDisabled, letterSpacing: 0.2, textAlign: 'center' },
  stepTextActive: { color: colors.textPrimary },
  details: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border, paddingTop: s(3), marginBottom: s(3) },
  productLine: { fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textPrimary, letterSpacing: 0.2, marginBottom: s(1) },
  summaryLine: { fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2, marginTop: s(1) },
  buyAgain: { alignSelf: 'flex-start', minHeight: s(10), borderRadius: s(5), paddingHorizontal: s(4), backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  buyAgainText: { marginLeft: s(2), fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.textInverse, letterSpacing: 0.2 },
  separator: { height: s(3) },
  pressed: { opacity: 0.72 },
});
