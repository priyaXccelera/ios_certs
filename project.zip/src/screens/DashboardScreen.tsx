import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import React, { useMemo } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { AppText } from '../components/AppText';
import { HeaderBar } from '../components/HeaderBar';
import { SummaryCard } from '../components/SummaryCard';
import { useAppData } from '../components/AppDataProvider';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface BusyRow { id: string; name: string; count: number; location: string }

export default function DashboardScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Dashboard'>>();
  const { appointments, staffMembers, locations } = useAppData();
  const completed = appointments.filter((item) => item.status === 'completed').length;
  const noShows = appointments.filter((item) => item.status === 'noShow').length;
  const confirmed = appointments.filter((item) => item.status === 'confirmed').length;
  const busyRows = useMemo<BusyRow[]>(() => staffMembers.map((staff) => ({
    id: staff.id,
    name: staff.name,
    count: appointments.filter((item) => item.staffId === staff.id && item.status !== 'cancelled').length,
    location: locations.find((loc) => loc.id === staff.locationId)?.name ?? 'Unknown location',
  })).sort((a, b) => b.count - a.count), [appointments, locations, staffMembers]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Dashboard" subtitle="Recent appointment activity" actionLabel="Book" onAction={() => navigation.navigate('Book')} />
      <View style={styles.content}>
        <View style={styles.summaryRow}>
          <SummaryCard label="Confirmed" value={`${confirmed}`} icon="calendar" />
          <View style={styles.cardGap} />
          <SummaryCard label="Completed" value={`${completed}`} icon="checkmark-circle" tone="success" />
        </View>
        <View style={styles.summaryRow}>
          <SummaryCard label="No-shows" value={`${noShows}`} icon="alert-circle" tone="warning" />
          <View style={styles.cardGap} />
          <SummaryCard label="Locations" value={`${locations.length}`} icon="business" tone="primary" />
        </View>
        <AppText variant="subtitle" style={styles.sectionTitle}>Staff workload</AppText>
        <FlatList
          style={styles.list}
          data={busyRows}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <Pressable onPress={() => navigation.navigate('StaffHours', { staffId: item.id })} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.row, pressed && Platform.OS === 'ios' && styles.pressed]}>
              <View style={styles.avatar}><Ionicons name="person" size={s(5)} color={colors.textInverse} /></View>
              <View style={styles.rowText}>
                <AppText variant="body" style={styles.rowTitle}>{item.name}</AppText>
                <AppText variant="caption">{item.location}</AppText>
              </View>
              <AppText variant="subtitle" style={styles.count}>{item.count}</AppText>
            </Pressable>
          )}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  content: { flex: 1, padding: s(4) },
  summaryRow: { flexDirection: 'row', minHeight: s(32), marginBottom: s(3) },
  cardGap: { width: s(3) },
  sectionTitle: { marginTop: s(3), marginBottom: s(3) },
  list: { flex: 1 },
  row: { minHeight: s(18), flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: s(3), padding: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  avatar: { width: s(10), height: s(10), borderRadius: s(5), backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: s(3) },
  rowText: { flex: 1 },
  rowTitle: { fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  count: { color: colors.primary },
  separator: { height: s(2) },
  pressed: { opacity: 0.7 },
});
