import { CartItem, CustomerProfile, Order, Product, WishlistItem } from '../types';

export const products: Product[] = [
  { id: 'p1', name: 'AeroPods Max Case', brand: 'Sukh Studio', category: 'Tech', price: 129, originalPrice: 169, rating: 4.8, reviewCount: 428, colors: ['Midnight', 'Silver', 'Blue'], sizes: ['One Size'], specs: ['MagSafe ready', 'Soft microfiber lining', 'Drop tested'], description: 'A premium protective case crafted for everyday iPhone-era accessories with a polished magnetic close.', collection: 'Premium Essentials', trending: true, recommended: true },
  { id: 'p2', name: 'Merino Travel Hoodie', brand: 'Northline', category: 'Fashion', price: 188, originalPrice: 240, rating: 4.7, reviewCount: 312, colors: ['Graphite', 'Cream'], sizes: ['S', 'M', 'L', 'XL'], specs: ['Merino blend', 'Hidden passport pocket', 'Machine washable'], description: 'A soft, structured hoodie designed for airport lounges, weekend escapes, and cool city evenings.', collection: 'Travel Edit', trending: true, recommended: false },
  { id: 'p3', name: 'Ceramic Aroma Lamp', brand: 'Casa Luma', category: 'Home', price: 84, originalPrice: 109, rating: 4.6, reviewCount: 198, colors: ['Clay', 'Snow'], sizes: ['One Size'], specs: ['Dimmable glow', 'USB-C power', 'Natural ceramic'], description: 'A warm ambient lamp that pairs gentle light with your favorite essential oils.', collection: 'Home Calm', trending: false, recommended: true },
  { id: 'p4', name: 'Silk Repair Serum', brand: 'Aurelia', category: 'Beauty', price: 56, originalPrice: 72, rating: 4.9, reviewCount: 621, colors: ['Amber'], sizes: ['30ml', '50ml'], specs: ['Vitamin C', 'Hyaluronic complex', 'Vegan formula'], description: 'A lightweight serum that gives skin a luminous, rested finish with daily use.', collection: 'Glow Rituals', trending: true, recommended: true },
  { id: 'p5', name: 'Nomad Weekender Bag', brand: 'Voyage', category: 'Travel', price: 228, originalPrice: 299, rating: 4.8, reviewCount: 287, colors: ['Olive', 'Black', 'Tan'], sizes: ['38L', '45L'], specs: ['Cabin friendly', 'Water resistant', 'Laptop sleeve'], description: 'A refined weekender with smart storage and an easy-carry silhouette.', collection: 'Travel Edit', trending: true, recommended: true },
  { id: 'p6', name: 'MagSafe Desk Stand', brand: 'Orbit', category: 'Tech', price: 76, originalPrice: 98, rating: 4.5, reviewCount: 143, colors: ['Space Gray', 'Silver'], sizes: ['One Size'], specs: ['15W charging', 'Weighted base', 'Adjustable tilt'], description: 'Keep your phone visible, charged, and ready during focus sessions.', collection: 'Desk Setup', trending: false, recommended: true },
  { id: 'p7', name: 'Tailored Linen Shirt', brand: 'Atelier Nine', category: 'Fashion', price: 94, originalPrice: 124, rating: 4.4, reviewCount: 176, colors: ['White', 'Sage', 'Navy'], sizes: ['XS', 'S', 'M', 'L'], specs: ['European linen', 'Relaxed fit', 'Pearl buttons'], description: 'Breathable linen with a sharp collar and relaxed weekend energy.', collection: 'Coastal Wardrobe', trending: false, recommended: true },
  { id: 'p8', name: 'Marble Catchall Tray', brand: 'Casa Luma', category: 'Home', price: 48, originalPrice: 64, rating: 4.6, reviewCount: 95, colors: ['White', 'Black'], sizes: ['Small', 'Large'], specs: ['Natural stone', 'Felt base', 'Hand polished'], description: 'A beautiful landing spot for keys, jewelry, and everyday essentials.', collection: 'Premium Essentials', trending: false, recommended: false },
  { id: 'p9', name: 'Hydra Cloud Cream', brand: 'Aurelia', category: 'Beauty', price: 62, originalPrice: 80, rating: 4.7, reviewCount: 344, colors: ['Pearl'], sizes: ['50ml'], specs: ['Ceramides', 'Fragrance free', 'Derm tested'], description: 'A cushiony moisturizer that hydrates deeply without heaviness.', collection: 'Glow Rituals', trending: true, recommended: true },
  { id: 'p10', name: 'Compact Packing Cubes', brand: 'Voyage', category: 'Travel', price: 42, originalPrice: 56, rating: 4.5, reviewCount: 212, colors: ['Ocean', 'Sand'], sizes: ['Set of 4'], specs: ['Compression zip', 'Mesh panels', 'Washable'], description: 'Organize more in less space with lightweight compression cubes.', collection: 'Travel Edit', trending: false, recommended: true },
  { id: 'p11', name: 'Noise Focus Earbuds', brand: 'Orbit', category: 'Tech', price: 149, originalPrice: 199, rating: 4.6, reviewCount: 534, colors: ['Black', 'White'], sizes: ['One Size'], specs: ['ANC', '30h battery', 'Spatial audio'], description: 'Immersive earbuds with crisp calls and calm silence on demand.', collection: 'Premium Essentials', trending: true, recommended: true },
  { id: 'p12', name: 'Cashmere Beanie', brand: 'Northline', category: 'Fashion', price: 68, originalPrice: 88, rating: 4.8, reviewCount: 119, colors: ['Oat', 'Charcoal'], sizes: ['One Size'], specs: ['Pure cashmere', 'Rib knit', 'Soft stretch'], description: 'A refined winter staple that feels soft from the first wear.', collection: 'Cozy Layers', trending: false, recommended: false }
];

export const initialCartItems: CartItem[] = [
  { id: 'c1', productId: 'p1', quantity: 1, color: 'Midnight', size: 'One Size' },
  { id: 'c2', productId: 'p7', quantity: 2, color: 'Sage', size: 'M' }
];

export const initialWishlistItems: WishlistItem[] = [
  { id: 'w1', productId: 'p5', savedAt: '2026-07-20' },
  { id: 'w2', productId: 'p9', savedAt: '2026-07-21' },
  { id: 'w3', productId: 'p11', savedAt: '2026-07-22' }
];

export const orders: Order[] = [
  { id: 'o1001', productIds: ['p4', 'p10'], total: 106, date: '2026-07-18', status: 'Delivered', address: '22 Apple Park Way, Cupertino', paymentMethod: 'Apple Pay' },
  { id: 'o1002', productIds: ['p2'], total: 188, date: '2026-07-20', status: 'Shipped', address: '22 Apple Park Way, Cupertino', paymentMethod: 'Visa ending 4242' },
  { id: 'o1003', productIds: ['p6', 'p8'], total: 124, date: '2026-07-23', status: 'Processing', address: '88 Market Street, San Francisco', paymentMethod: 'Apple Pay' },
  { id: 'o1004', productIds: ['p12'], total: 68, date: '2026-07-24', status: 'Packed', address: '22 Apple Park Way, Cupertino', paymentMethod: 'Mastercard ending 1905' }
];

export const profile: CustomerProfile = {
  name: 'Sukhmeet Singh',
  email: 'sukhmeet@example.com',
  tier: 'Platinum Member',
  notifications: true,
  darkMode: false,
  privacyMode: true,
  addresses: [
    { id: 'a1', label: 'Home', detail: '22 Apple Park Way, Cupertino' },
    { id: 'a2', label: 'Studio', detail: '88 Market Street, San Francisco' }
  ]
};

export const categories = ['All', 'Tech', 'Fashion', 'Home', 'Beauty', 'Travel'] as const;
