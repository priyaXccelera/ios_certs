import React from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type InputFieldProps = {
  label: string;
  value: string;
  placeholder: string;
  onChangeText: (text: string) => void;
  error?: string;
  multiline?: boolean;
  secureTextEntry?: boolean;
};

export function InputField({
  label,
  value,
  placeholder,
  onChangeText,
  error,
  multiline,
  secureTextEntry,
}: InputFieldProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        placeholder={placeholder}
        placeholderTextColor={colors.textDisabled}
        onChangeText={onChangeText}
        multiline={multiline}
        secureTextEntry={secureTextEntry}
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="done"
        underlineColorAndroid="transparent"
        selectionColor={colors.primary}
        style={[styles.input, multiline && styles.inputMultiline, error ? styles.inputError : undefined]}
      />
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: s(4),
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 12 * 1.2,
    letterSpacing: 1.2,
    color: colors.textSecondary,
    textTransform: 'uppercase',
    marginBottom: s(2),
    fontFamily: 'Inter-SemiBold',
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: s(2),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    paddingHorizontal: s(3),
    paddingVertical: s(3),
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 14 * 1.4,
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-Regular',
  },
  inputMultiline: {
    minHeight: s(24),
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: colors.error,
  },
  errorText: {
    marginTop: s(1),
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 12 * 1.4,
    letterSpacing: 0.2,
    color: colors.error,
    fontFamily: 'Inter-Regular',
  },
});
