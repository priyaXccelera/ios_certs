import { StatusBar } from 'expo-status-bar';
import React, { useMemo, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { WaitlistEntry } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function WaitlistScreen() {
  const { waitlistEntries, locations, services, staffMembers, addWaitlistEntry, toggleWaitlistNotification } = useAppData();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [locationId, setLocationId] = useState(locations[0]?.id ?? '');
  const [serviceId, setServiceId] = useState(services[0]?.id ?? '');
  const [staffId, setStaffId] = useState('any');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const eligibleStaff = useMemo(() => staffMembers.filter((staff) => staff.locationId === locationId && staff.serviceIds.includes(serviceId)), [locationId, serviceId, staffMembers]);
  const add = () => {
    const entry: WaitlistEntry = { id: `wait-${Date.now()}`, customerName: name.trim() || 'Waitlist Customer', customerEmail: email.trim() || 'wait@example.com', locationId, serviceId, staffId: staffId === 'any' ? undefined : staffId, date, createdAtIso: new Date().toISOString(), notified: false };
    addWaitlistEntry(entry);
    setName(''); setEmail(''); setStaffId('any');
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Waitlist" subtitle="People waiting for fully booked days" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}>
          <TextInput value={name} onChangeText={setName} placeholder="Customer name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={email} onChangeText={setEmail} placeholder="Email" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={item.name} selected={locationId === item.id} onPress={() => setLocationId(item.id)} />)}</View>
          <View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={item.name} selected={serviceId === item.id} onPress={() => setServiceId(item.id)} />)}</View>
          <View style={styles.wrap}><Chip label="Any staff" selected={staffId === 'any'} onPress={() => setStaffId('any')} />{eligibleStaff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => setStaffId(item.id)} />)}</View>
          <PrimaryButton label="Add waitlist entry" onPress={add} />
        </View>
        <FlatList
          style={styles.list}
          data={waitlistEntries}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => { const service = services.find((svc) => svc.id === item.serviceId); const staff = staffMembers.find((member) => member.id === item.staffId); const location = locations.find((loc) => loc.id === item.locationId); return <Pressable onPress={() => toggleWaitlistNotification(item.id)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.row, item.notified && styles.notified, pressed && Platform.OS === 'ios' && styles.pressed]}><View style={styles.rowTop}><AppText variant="subtitle">{item.customerName}</AppText><AppText variant="caption" style={item.notified ? styles.notifiedText : styles.pendingText}>{item.notified ? 'Notified' : 'Waiting'}</AppText></View><AppText variant="caption">{item.date} · {service?.name ?? 'Service'} · {staff?.name ?? 'Any staff'} · {location?.name ?? 'Location'}</AppText></Pressable>; }}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
        />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: s(1) },
  list: { flex: 1, padding: s(4) },
  row: { minHeight: s(20), padding: s(3), backgroundColor: colors.surface, borderRadius: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  notified: { borderColor: colors.success, backgroundColor: colors.primaryLight },
  rowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: s(2) },
  notifiedText: { color: colors.success, fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  pendingText: { color: colors.warning, fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  separator: { height: s(2) },
  pressed: { opacity: 0.7 },
});
