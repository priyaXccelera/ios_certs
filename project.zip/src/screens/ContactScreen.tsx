import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { InputField } from '../components/InputField';
import { PrimaryButton } from '../components/PrimaryButton';
import { SecondaryButton } from '../components/SecondaryButton';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ContactScreen() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [success, setSuccess] = useState(false);

  const handleSubmit = () => {
    const nextErrors: { [key: string]: string } = {};
    if (!name.trim()) nextErrors.name = 'Name is required.';
    if (!email.includes('@')) nextErrors.email = 'Enter a valid email.';
    if (!company.trim()) nextErrors.company = 'Company is required.';
    if (!message.trim()) nextErrors.message = 'Message is required.';
    setErrors(nextErrors);
    const isValid = Object.keys(nextErrors).length === 0;
    setSuccess(isValid);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setCompany('');
    setMessage('');
    setErrors({});
    setSuccess(false);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <SectionHeader title="Contact" subtitle="Talk with our team about scaling engagement." />
        <InputField
          label="Name"
          value={name}
          placeholder="Jane Cooper"
          onChangeText={setName}
          error={errors.name}
        />
        <InputField
          label="Email"
          value={email}
          placeholder="jane@company.com"
          onChangeText={setEmail}
          error={errors.email}
        />
        <InputField
          label="Company"
          value={company}
          placeholder="Company name"
          onChangeText={setCompany}
          error={errors.company}
        />
        <InputField
          label="Message"
          value={message}
          placeholder="How can we help?"
          onChangeText={setMessage}
          error={errors.message}
          multiline
        />
        {success ? <Text style={styles.successText}>Message sent! We will reach out shortly.</Text> : null}
        <View style={styles.buttonRow}>
          <PrimaryButton label="Submit" onPress={handleSubmit} />
          <View style={styles.buttonSpacer} />
          <SecondaryButton label="Reset" onPress={handleReset} />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  container: {
    flex: 1,
    paddingTop: s(5),
  },
  buttonRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonSpacer: {
    width: s(3),
  },
  successText: {
    marginBottom: s(3),
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-SemiBold',
  },
});
