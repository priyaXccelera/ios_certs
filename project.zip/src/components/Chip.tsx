import React from 'react';
import { Platform, Pressable, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { AppText } from './AppText';

interface ChipProps {
  label: string;
  selected?: boolean;
  onPress: () => void;
}

export function Chip({ label, selected = false, onPress }: ChipProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
      style={({ pressed }) => [styles.chip, selected && styles.selected, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <AppText variant="caption" style={[styles.text, selected && styles.selectedText]}>{label}</AppText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    paddingVertical: s(2),
    borderRadius: s(6),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    marginRight: s(2),
    marginBottom: s(2),
    alignItems: 'center',
    justifyContent: 'center',
  },
  selected: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  text: {
    color: colors.textSecondary,
  },
  selectedText: {
    color: colors.textInverse,
    fontFamily: 'Inter-SemiBold',
    fontWeight: '600',
  },
  pressed: {
    opacity: 0.72,
  },
});
