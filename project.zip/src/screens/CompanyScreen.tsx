import React from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { InfoCard } from '../components/InfoCard';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { companyValues } from '../data/mockData';

export default function CompanyScreen() {
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <SectionHeader title="Company" subtitle="A trusted partner for modern customer engagement." />
      <View style={styles.missionCard}>
        <Text style={styles.missionTitle}>Mission</Text>
        <Text style={styles.missionText}>
          Empower every enterprise team to deliver fast, personal, and measurable customer engagement.
        </Text>
      </View>
      <FlatList
        data={companyValues}
        style={styles.list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <InfoCard title={item.title} description={item.detail} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    paddingTop: s(5),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  missionCard: {
    backgroundColor: colors.surface,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    marginBottom: s(4),
  },
  missionTitle: {
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 16 * 1.2,
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  missionText: {
    marginTop: s(2),
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
});
