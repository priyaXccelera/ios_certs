import React from 'react';
import { Pressable, StyleSheet, Text, View, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type DrawerLinkProps = {
  label: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  onPress: () => void;
  active?: boolean;
};

export function DrawerLink({ label, icon, onPress, active }: DrawerLinkProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.container, active && styles.active, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <MaterialIcons name={icon} size={20} color={active ? colors.primaryDark : colors.textSecondary} />
      <Text style={[styles.label, active && styles.labelActive]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: s(3),
    paddingHorizontal: s(4),
    borderRadius: s(2),
  },
  active: {
    backgroundColor: colors.primaryLight,
  },
  pressed: {
    opacity: 0.7,
  },
  label: {
    marginLeft: s(3),
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 14 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  labelActive: {
    color: colors.primaryDark,
    fontWeight: '600',
    fontFamily: 'Inter-SemiBold',
  },
});
