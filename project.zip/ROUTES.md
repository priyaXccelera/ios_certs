# SSO ios — Screens & Navigation

## How to run
cd /home/ryzen/frontend_generator_backend/frontend_runs/run_8fdb94a0_20260724_114804/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Auth | src/screens/AuthScreen.tsx | Normal sign-in/create-account screen; any typed credentials enter the app. |
| Dashboard | src/screens/DashboardScreen.tsx | Summary metrics for confirmed, completed, no-show appointments and staff workload. |
| Book | src/screens/BookScreen.tsx | Browse and book by location, service, eligible staff/anyone, day, and open 15-minute slot. |
| Confirmation | src/screens/ConfirmationScreen.tsx | Immediate booking confirmation with service, staff, location, time, and exact price. |
| Appointments | src/screens/AppointmentsScreen.tsx | Searchable/filterable list of every appointment across all locations and staff. |
| AppointmentDetail | src/screens/AppointmentDetailScreen.tsx | Appointment actions: cancel when more than 24 hours away, mark past appointments completed/no-show. |
| Manage | src/screens/ManageScreen.tsx | Hub for locations, services, staff, and staff-hour management. |
| Locations | src/screens/LocationsScreen.tsx | Add/edit locations with city, address, and timezone. |
| Services | src/screens/ServicesScreen.tsx | Add/edit services with duration, exact cents-based price, and trained staff. |
| Staff | src/screens/StaffScreen.tsx | Add/edit staff, assigned location, role, and services they can perform. |
| StaffHours | src/screens/StaffHoursScreen.tsx | Set weekly working blocks and date-specific day-off/custom-hour overrides. |
| Waitlist | src/screens/WaitlistScreen.tsx | View and add waitlist entries, toggle notification state. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen with a back action. |

## Navigation map
- Auth -> MainTabs (tap Sign in / Create account).
- MainTabs -> Dashboard / Book / Appointments / Manage / Waitlist (tap bottom tab).
- Dashboard -> Book (tap Book header action).
- Dashboard -> StaffHours (tap staff workload row).
- Book -> Confirmation (tap Confirm appointment after selecting an available slot).
- Book -> Waitlist (tap Add to waitlist when a day is full or by choice).
- Confirmation -> MainTabs (tap back header action) or Appointments (tap View all appointments).
- Appointments -> Book (tap Book header action or empty-list button).
- Appointments -> AppointmentDetail (tap appointment card).
- AppointmentDetail -> previous screen (tap header back).
- Manage -> Locations (tap Locations row).
- Manage -> Services (tap Services row).
- Manage -> Staff (tap Staff members row).
- Manage -> StaffHours (tap Staff hours row).
- Locations / Services / Staff / StaffHours -> previous screen (tap header back).

## Shared components
- src/components/AppText.tsx — Inter-backed text wrapper with title, subtitle, body, caption, and label variants.
- src/components/AppDataProvider.tsx — Shared in-memory state provider seeded from typed mock data; supports create/edit/status/toggle mutations.
- src/components/HeaderBar.tsx — Reusable native-style header with optional back button and action button.
- src/components/PrimaryButton.tsx — Pressable CTA button with primary, secondary, and danger styles.
- src/components/Chip.tsx — Selectable Pressable chip used for filters and picker choices.
- src/components/SummaryCard.tsx — Dashboard metric card with icon and platform shadows.

## Design tokens
- primary: #2563EB
- primaryDark: #1E40AF
- primaryLight: #DBEAFE
- accent: #F59E0B
- background: #F8FAFC
- surface: #FFFFFF
- card: #FFFFFF
- border: #E2E8F0
- textPrimary: #0F172A
- textSecondary: #64748B
- textDisabled: #94A3B8
- textInverse: #FFFFFF
- success: #16A34A
- warning: #D97706
- error: #DC2626
- info: #0284C7
- shadowColor: #000000
