import React from 'react';
import { Pressable, StyleSheet, Text, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type InlineLinkProps = {
  label: string;
  onPress: () => void;
};

export function InlineLink({ label, onPress }: InlineLinkProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.container, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: s(2),
  },
  pressed: {
    opacity: 0.7,
  },
  label: {
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.primaryDark,
    fontFamily: 'Inter-Medium',
  },
});
