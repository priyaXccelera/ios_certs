import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Product } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ProductCardProps {
  product: Product;
  onPress: () => void;
  onSave: () => void;
  saved: boolean;
  compact?: boolean;
}

export function ProductCard({ product, onPress, onSave, saved, compact }: ProductCardProps) {
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
  return (
    <View style={[styles.card, compact && styles.compactCard]}>
      <Pressable
        onPress={onPress}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
        style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.primaryPressed]}
      />
      <View pointerEvents="none" style={styles.content}>
        <View style={styles.imagePlaceholder}>
          <Ionicons name="bag-handle-outline" size={s(8)} color={colors.textDisabled} />
        </View>
        <View style={styles.textWrap}>
          <Text style={styles.brand}>{product.brand}</Text>
          <Text numberOfLines={compact ? 1 : 2} style={styles.name}>{product.name}</Text>
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={s(3)} color={colors.accent} />
            <Text style={styles.rating}>{product.rating.toFixed(1)} · {product.reviewCount}</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.price}>${product.price}</Text>
            <Text style={styles.original}>${product.originalPrice}</Text>
            <Text style={styles.discount}>{discount}% OFF</Text>
          </View>
        </View>
      </View>
      <Pressable
        onPress={onSave}
        hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
        style={({ pressed }) => [styles.saveButton, pressed && Platform.OS === 'ios' && styles.primaryPressed]}
      >
        <Ionicons name={saved ? 'heart' : 'heart-outline'} size={s(5)} color={saved ? colors.error : colors.textPrimary} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: s(44),
    minHeight: s(70),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginRight: s(3),
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.1,
        shadowRadius: s(2),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  compactCard: {
    width: s(40),
    minHeight: s(64),
  },
  primaryPressed: {
    opacity: 0.74,
  },
  content: {
    flex: 1,
    padding: s(3),
  },
  imagePlaceholder: {
    height: s(32),
    borderRadius: s(3),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(3),
  },
  textWrap: {
    flex: 1,
  },
  brand: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    color: colors.textSecondary,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  name: {
    marginTop: s(1),
    fontFamily: 'Inter-SemiBold',
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '600',
    color: colors.textPrimary,
    letterSpacing: 0.2,
  },
  ratingRow: {
    marginTop: s(2),
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    marginLeft: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '400',
    color: colors.textSecondary,
    letterSpacing: 0.2,
  },
  priceRow: {
    marginTop: s(2),
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  price: {
    fontFamily: 'Inter-Bold',
    fontSize: s(5),
    lineHeight: s(5) * 1.2,
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  original: {
    marginLeft: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '400',
    color: colors.textDisabled,
    textDecorationLine: 'line-through',
    letterSpacing: 0.2,
  },
  discount: {
    marginTop: s(1),
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    color: colors.success,
    letterSpacing: 0.2,
  },
  saveButton: {
    position: 'absolute',
    top: s(4),
    right: s(4),
    width: s(9),
    height: s(9),
    borderRadius: s(5),
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
