export type ProductCategory = 'All' | 'Tech' | 'Fashion' | 'Home' | 'Beauty' | 'Travel';

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: Exclude<ProductCategory, 'All'>;
  price: number;
  originalPrice: number;
  rating: number;
  reviewCount: number;
  colors: string[];
  sizes: string[];
  specs: string[];
  description: string;
  collection: string;
  trending: boolean;
  recommended: boolean;
}

export interface CartItem {
  id: string;
  productId: string;
  quantity: number;
  color: string;
  size: string;
}

export interface WishlistItem {
  id: string;
  productId: string;
  savedAt: string;
}

export type OrderStatus = 'Processing' | 'Packed' | 'Shipped' | 'Delivered';

export interface Order {
  id: string;
  productIds: string[];
  total: number;
  date: string;
  status: OrderStatus;
  address: string;
  paymentMethod: string;
}

export interface Address {
  id: string;
  label: string;
  detail: string;
}

export interface CustomerProfile {
  name: string;
  email: string;
  tier: string;
  notifications: boolean;
  darkMode: boolean;
  privacyMode: boolean;
  addresses: Address[];
}
