import React from 'react';
import { Platform, Pressable, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { AppText } from './AppText';

interface PrimaryButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
}

export function PrimaryButton({ label, onPress, variant = 'primary', disabled = false }: PrimaryButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
      style={({ pressed }) => [styles.button, styles[variant], disabled && styles.disabled, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <AppText variant="body" style={[styles.text, variant !== 'primary' && styles.secondaryText, disabled && styles.disabledText]}>{label}</AppText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: s(12),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    borderRadius: s(2),
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: {
    backgroundColor: colors.primary,
  },
  secondary: {
    backgroundColor: colors.primaryLight,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.primary,
  },
  danger: {
    backgroundColor: colors.error,
  },
  disabled: {
    backgroundColor: colors.border,
  },
  text: {
    color: colors.textInverse,
    fontFamily: 'Inter-SemiBold',
    fontWeight: '600',
  },
  secondaryText: {
    color: colors.primaryDark,
  },
  disabledText: {
    color: colors.textDisabled,
  },
  pressed: {
    opacity: 0.75,
  },
});
