import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { formatMoney } from '../data/mockData';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function AppointmentDetailScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'AppointmentDetail'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'AppointmentDetail'>>();
  const { appointments, services, staffMembers, locations, updateAppointmentStatus, waitlistEntries, toggleWaitlistNotification } = useAppData();
  const appointment = appointments.find((item) => item.id === route.params.id);
  const service = services.find((item) => item.id === appointment?.serviceId);
  const staff = staffMembers.find((item) => item.id === appointment?.staffId);
  const location = locations.find((item) => item.id === appointment?.locationId);
  const startTime = appointment ? new Date(appointment.startIso).getTime() : 0;
  const isPast = startTime < Date.now();
  const canCancel = appointment?.status === 'confirmed' && startTime - Date.now() > 24 * 60 * 60 * 1000;
  const canFinalize = appointment?.status === 'confirmed' && isPast;

  const cancel = () => {
    if (!appointment || !canCancel) return;
    updateAppointmentStatus(appointment.id, 'cancelled');
    const waiting = waitlistEntries.filter((entry) => entry.locationId === appointment.locationId && entry.serviceId === appointment.serviceId && entry.date === appointment.startIso.slice(0, 10) && (!entry.staffId || entry.staffId === appointment.staffId) && !entry.notified).sort((a, b) => new Date(a.createdAtIso).getTime() - new Date(b.createdAtIso).getTime())[0];
    if (waiting) toggleWaitlistNotification(waiting.id);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Appointment" subtitle={appointment?.status ?? 'Unknown'} onBack={() => navigation.goBack()} />
      <View style={styles.content}>
        <View style={styles.card}>
          <AppText variant="title">{appointment?.customerName ?? 'Missing appointment'}</AppText>
          <AppText variant="body" style={styles.line}>{service?.name ?? 'Service'} · {formatMoney(appointment?.priceCents ?? 0)}</AppText>
          <AppText variant="body" style={styles.line}>{appointment ? new Date(appointment.startIso).toLocaleString() : 'No time'}</AppText>
          <AppText variant="body" style={styles.line}>{staff?.name ?? 'Staff'} · {location?.name ?? 'Location'}</AppText>
          <AppText variant="caption" style={styles.note}>Final states cannot be changed. Cancellations are available only more than 24 hours before the appointment.</AppText>
        </View>
        <PrimaryButton label="Cancel appointment" onPress={cancel} variant="danger" disabled={!canCancel} />
        <View style={styles.gap} />
        <PrimaryButton label="Mark completed" onPress={() => appointment && canFinalize ? updateAppointmentStatus(appointment.id, 'completed') : navigation.goBack()} disabled={!canFinalize} />
        <View style={styles.gap} />
        <PrimaryButton label="Mark no-show" onPress={() => appointment && canFinalize ? updateAppointmentStatus(appointment.id, 'noShow') : navigation.goBack()} variant="secondary" disabled={!canFinalize} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  content: { flex: 1, padding: s(4) },
  card: { backgroundColor: colors.surface, borderRadius: s(3), padding: s(4), marginBottom: s(4), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  line: { color: colors.textSecondary, marginTop: s(3) },
  note: { marginTop: s(4) },
  gap: { height: s(3) },
});
