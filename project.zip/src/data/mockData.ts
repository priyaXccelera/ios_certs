import { Product } from '../types';

export const products: Product[] = [
  { id: '1', name: 'Air Max Pulse', brand: 'Nike', price: 159, rating: 4.6, category: 'Shoes' },
  { id: '2', name: 'Classic Tee', brand: 'Uniqlo', price: 29, rating: 4.2, category: 'Apparel' },
  { id: '3', name: 'Leather Wallet', brand: 'Bellroy', price: 89, rating: 4.7, category: 'Accessories' },
  { id: '4', name: 'Running Shorts', brand: 'Adidas', price: 45, rating: 4.3, category: 'Apparel' }
];