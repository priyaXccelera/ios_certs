import React, { useMemo, useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { HeaderBar } from '../components/HeaderBar';
import { ProductCard } from '../components/ProductCard';
import { products } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { RootStackParamList } from '../navigation';

type DetailsRoute = RouteProp<RootStackParamList, 'ProductDetails'>;
type DetailsNavigation = NativeStackNavigationProp<RootStackParamList, 'ProductDetails'>;

export default function ProductDetailsScreen() {
  const route = useRoute<DetailsRoute>();
  const navigation = useNavigation<DetailsNavigation>();
  const product = products.find((item) => item.id === route.params.id) ?? products[0];
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [saved, setSaved] = useState(false);
  const [galleryIndex, setGalleryIndex] = useState(0);

  const related = useMemo(() => products.filter((item) => item.category === product.category && item.id !== product.id).slice(0, 4), [product]);
  const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);

  const addToCart = () => {
    Alert.alert('Added to Cart', `${product.name} in ${selectedColor} / ${selectedSize} was added locally.`);
    navigation.navigate('MainTabs', { screen: 'Cart' });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Details" subtitle={product.brand} onBack={() => navigation.goBack()} actionIcon={saved ? 'heart' : 'heart-outline'} onAction={() => setSaved((prev) => !prev)} />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScrollView horizontal pagingEnabled directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.galleryRow}>
          {[0, 1, 2].map((index) => (
            <Pressable
              key={index}
              onPress={() => setGalleryIndex(index)}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.galleryItem, pressed && Platform.OS === 'ios' && styles.pressed]}
            >
              <Ionicons name="cube-outline" size={s(18)} color={colors.primary} />
              <Text style={styles.galleryText}>Image {index + 1}</Text>
            </Pressable>
          ))}
        </ScrollView>
        <View style={styles.dots}>
          {[0, 1, 2].map((index) => <View key={index} style={[styles.dot, galleryIndex === index && styles.dotActive]} />)}
        </View>
        <View style={styles.card}>
          <Text style={styles.brand}>{product.brand}</Text>
          <Text style={styles.name}>{product.name}</Text>
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={s(4)} color={colors.accent} />
            <Text style={styles.rating}>{product.rating.toFixed(1)} rating · {product.reviewCount} reviews</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.price}>${product.price}</Text>
            <Text style={styles.original}>${product.originalPrice}</Text>
            <Text style={styles.discount}>Save {discount}%</Text>
          </View>
          <Text style={styles.description}>{product.description}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Colors</Text>
          <View style={styles.optionRow}>
            {product.colors.map((color) => (
              <Pressable key={color} onPress={() => setSelectedColor(color)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.option, selectedColor === color && styles.optionActive, pressed && Platform.OS === 'ios' && styles.pressed]}>
                <Text style={[styles.optionText, selectedColor === color && styles.optionTextActive]}>{color}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={styles.sectionTitle}>Sizes</Text>
          <View style={styles.optionRow}>
            {product.sizes.map((size) => (
              <Pressable key={size} onPress={() => setSelectedSize(size)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.option, selectedSize === size && styles.optionActive, pressed && Platform.OS === 'ios' && styles.pressed]}>
                <Text style={[styles.optionText, selectedSize === size && styles.optionTextActive]}>{size}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Specifications</Text>
          {product.specs.map((spec) => (
            <View key={spec} style={styles.specRow}>
              <Ionicons name="checkmark-circle" size={s(5)} color={colors.success} />
              <Text style={styles.specText}>{spec}</Text>
            </View>
          ))}
        </View>
        <Text style={styles.relatedTitle}>Related items</Text>
        <ScrollView horizontal directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.relatedRow}>
          {related.map((item) => (
            <ProductCard key={item.id} compact product={item} onPress={() => navigation.push('ProductDetails', { id: item.id })} onSave={() => setSaved(true)} saved={saved} />
          ))}
        </ScrollView>
      </ScrollView>
      <View style={styles.footer}>
        <Pressable onPress={() => setSaved((prev) => !prev)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.saveButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Ionicons name={saved ? 'bookmark' : 'bookmark-outline'} size={s(5)} color={colors.primary} />
          <Text style={styles.saveText}>{saved ? 'Saved' : 'Save'}</Text>
        </Pressable>
        <Pressable onPress={addToCart} android_ripple={{ color: 'rgba(0,0,0,0.12)' }} style={({ pressed }) => [styles.cartButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Text style={styles.cartText}>Add to Cart</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}) },
  scroll: { flex: 1 },
  content: { paddingBottom: s(28) },
  galleryRow: { paddingHorizontal: s(4), paddingVertical: s(2) },
  galleryItem: { width: s(84), height: s(72), borderRadius: s(5), backgroundColor: colors.primaryLight, marginRight: s(4), alignItems: 'center', justifyContent: 'center' },
  galleryText: { marginTop: s(2), fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 0.2 },
  dots: { flexDirection: 'row', alignSelf: 'center', marginBottom: s(4) },
  dot: { width: s(2), height: s(2), borderRadius: s(1), backgroundColor: colors.border, marginHorizontal: s(1) },
  dotActive: { width: s(6), backgroundColor: colors.primary },
  card: { marginHorizontal: s(4), marginBottom: s(4), padding: s(4), borderRadius: s(4), backgroundColor: colors.card, ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 3 }, default: {} }) },
  brand: { fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 1.2, textTransform: 'uppercase' },
  name: { marginTop: s(1), fontFamily: 'Inter-Bold', fontSize: s(8), lineHeight: s(8) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  ratingRow: { marginTop: s(3), flexDirection: 'row', alignItems: 'center' },
  rating: { marginLeft: s(2), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  priceRow: { marginTop: s(4), flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  price: { fontFamily: 'Inter-Bold', fontSize: s(8), lineHeight: s(8) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  original: { marginLeft: s(3), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textDisabled, textDecorationLine: 'line-through', letterSpacing: 0.2 },
  discount: { marginLeft: s(3), fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.success, letterSpacing: 0.2 },
  description: { marginTop: s(4), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  sectionTitle: { marginTop: s(2), marginBottom: s(3), fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  optionRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: s(3) },
  option: { minHeight: s(10), borderRadius: s(5), paddingHorizontal: s(4), marginRight: s(2), marginBottom: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  optionActive: { backgroundColor: colors.textPrimary, borderColor: colors.textPrimary },
  optionText: { fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.textPrimary, letterSpacing: 0.2 },
  optionTextActive: { color: colors.textInverse },
  specRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: s(2), borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  specText: { marginLeft: s(2), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textPrimary, letterSpacing: 0.2 },
  relatedTitle: { marginHorizontal: s(4), marginBottom: s(3), fontFamily: 'Inter-Bold', fontSize: s(6), lineHeight: s(6) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  relatedRow: { paddingHorizontal: s(4), paddingBottom: s(4) },
  footer: { position: 'absolute', left: 0, right: 0, bottom: 0, minHeight: s(22), padding: s(4), backgroundColor: colors.surface, flexDirection: 'row', borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  saveButton: { minHeight: s(14), borderRadius: s(4), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(4), marginRight: s(3), flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  saveText: { marginLeft: s(2), fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 0.2 },
  cartButton: { flex: 1, minHeight: s(14), borderRadius: s(4), backgroundColor: colors.textPrimary, alignItems: 'center', justifyContent: 'center' },
  cartText: { fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', color: colors.textInverse, letterSpacing: 0.2 },
  pressed: { opacity: 0.72 },
});
