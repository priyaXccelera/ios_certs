import React from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { Plan } from '../types';
import { PrimaryButton } from './PrimaryButton';

type PricingCardProps = {
  plan: Plan;
  onSelect: () => void;
};

export function PricingCard({ plan, onSelect }: PricingCardProps) {
  return (
    <View style={[styles.card, plan.highlight && styles.highlightCard]}>
      <Text style={styles.planName}>{plan.name}</Text>
      <Text style={styles.price}>{plan.price}</Text>
      <View style={styles.featureList}>
        {plan.features.map((feature) => (
          <View key={feature} style={styles.featureRow}>
            <MaterialIcons name="check-circle" size={18} color={colors.primary} />
            <Text style={styles.featureText}>{feature}</Text>
          </View>
        ))}
      </View>
      <PrimaryButton label={plan.highlight ? 'Start Professional' : 'Choose Plan'} onPress={onSelect} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    marginBottom: s(4),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: { elevation: 6 },
      default: {},
    }),
  },
  highlightCard: {
    backgroundColor: colors.primaryLight,
    borderColor: colors.primary,
  },
  planName: {
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 18 * 1.2,
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  price: {
    marginTop: s(2),
    fontSize: 20,
    fontWeight: '700',
    lineHeight: 20 * 1.2,
    letterSpacing: -0.5,
    color: colors.primaryDark,
    fontFamily: 'Inter-Bold',
  },
  featureList: {
    marginTop: s(3),
    marginBottom: s(4),
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: s(2),
  },
  featureText: {
    marginLeft: s(2),
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
});
