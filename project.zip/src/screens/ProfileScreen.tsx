import React, { useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { profile as mockProfile } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ProfileScreen() {
  const [notifications, setNotifications] = useState(mockProfile.notifications);
  const [darkMode, setDarkMode] = useState(mockProfile.darkMode);
  const [privacyMode, setPrivacyMode] = useState(mockProfile.privacyMode);

  const updateSetting = (name: string, setter: (value: boolean) => void, value: boolean) => {
    setter(value);
    Alert.alert('Preference saved', `${name} updated locally.`);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Profile" subtitle="Preferences and account" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.heroCard}>
          <View style={styles.avatar}><Ionicons name="person" size={s(8)} color={colors.textInverse} /></View>
          <View style={styles.heroText}>
            <Text style={styles.name}>{mockProfile.name}</Text>
            <Text style={styles.email}>{mockProfile.email}</Text>
            <Text style={styles.tier}>{mockProfile.tier}</Text>
          </View>
        </View>
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Saved addresses</Text>
          {mockProfile.addresses.map((address) => (
            <View key={address.id} style={styles.addressRow}>
              <Ionicons name="location-outline" size={s(5)} color={colors.primary} />
              <View style={styles.addressText}>
                <Text style={styles.addressLabel}>{address.label}</Text>
                <Text style={styles.addressDetail}>{address.detail}</Text>
              </View>
            </View>
          ))}
        </View>
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Settings</Text>
          <View style={styles.settingRow}>
            <View><Text style={styles.settingTitle}>Notifications</Text><Text style={styles.settingMeta}>Order alerts and offers</Text></View>
            <Switch value={notifications} onValueChange={(value) => updateSetting('Notifications', setNotifications, value)} trackColor={{ false: colors.border, true: colors.primaryLight }} thumbColor={notifications ? colors.primary : colors.textDisabled} />
          </View>
          <View style={styles.settingRow}>
            <View><Text style={styles.settingTitle}>Appearance</Text><Text style={styles.settingMeta}>Simulated dark mode preference</Text></View>
            <Switch value={darkMode} onValueChange={(value) => updateSetting('Appearance', setDarkMode, value)} trackColor={{ false: colors.border, true: colors.primaryLight }} thumbColor={darkMode ? colors.primary : colors.textDisabled} />
          </View>
          <View style={styles.settingRow}>
            <View><Text style={styles.settingTitle}>Privacy mode</Text><Text style={styles.settingMeta}>Limit recommendation tracking</Text></View>
            <Switch value={privacyMode} onValueChange={(value) => updateSetting('Privacy mode', setPrivacyMode, value)} trackColor={{ false: colors.border, true: colors.primaryLight }} thumbColor={privacyMode ? colors.primary : colors.textDisabled} />
          </View>
        </View>
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.aboutText}>SUKHMEET ios is an offline Expo shopping demo with mock products, checkout simulation, order history, saved items and polished iPhone-first UI.</Text>
          <Pressable onPress={() => Alert.alert('Version', 'SUKHMEET ios 1.0.0')} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.aboutButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
            <Text style={styles.aboutButtonText}>Application details</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}) },
  scroll: { flex: 1 },
  content: { paddingHorizontal: s(4), paddingBottom: s(8) },
  heroCard: { borderRadius: s(5), backgroundColor: colors.textPrimary, padding: s(5), flexDirection: 'row', alignItems: 'center', marginBottom: s(4) },
  avatar: { width: s(18), height: s(18), borderRadius: s(9), backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: s(4) },
  heroText: { flex: 1 },
  name: { fontFamily: 'Inter-Bold', fontSize: s(6), lineHeight: s(6) * 1.2, fontWeight: '700', color: colors.textInverse, letterSpacing: -0.5 },
  email: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textInverse, letterSpacing: 0.2 },
  tier: { marginTop: s(2), fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.accent, letterSpacing: 1.2, textTransform: 'uppercase' },
  sectionCard: { borderRadius: s(4), backgroundColor: colors.card, padding: s(4), marginBottom: s(4), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 3 }, default: {} }) },
  sectionTitle: { marginBottom: s(3), fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  addressRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: s(3), borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  addressText: { marginLeft: s(3), flex: 1 },
  addressLabel: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.textPrimary, letterSpacing: 0.2 },
  addressDetail: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  settingRow: { minHeight: s(16), flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  settingTitle: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.textPrimary, letterSpacing: 0.2 },
  settingMeta: { fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  aboutText: { fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  aboutButton: { minHeight: s(12), borderRadius: s(3), backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginTop: s(4) },
  aboutButtonText: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 0.2 },
  pressed: { opacity: 0.72 },
});
