import React, { useEffect } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { FeatureCard } from '../components/FeatureCard';
import { PrimaryButton } from '../components/PrimaryButton';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { features } from '../data/mockData';
import { DrawerParamList } from '../navigation';

export default function FeaturesScreen() {
  const navigation = useNavigation<DrawerNavigationProp<DrawerParamList, 'Features'>>();
  const fade = useSharedValue(0);

  useEffect(() => {
    fade.value = withTiming(1, { duration: 450 });
  }, [fade]);

  const fadeStyle = useAnimatedStyle(() => ({
    opacity: fade.value,
  }));

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <Animated.View style={[styles.header, fadeStyle]}>
        <SectionHeader
          title="Features"
          subtitle="Analytics, community, and automation built for high-growth teams."
        />
      </Animated.View>
      <FlatList
        data={features}
        style={styles.list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cardWrap}>
            <FeatureCard feature={item} />
          </View>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ListFooterComponent={
          <View style={styles.footer}>
            <Text style={styles.footerText}>Ready to activate automation and reporting?</Text>
            <PrimaryButton label="View Pricing" onPress={() => navigation.navigate('Pricing')} />
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  header: {
    paddingTop: s(5),
  },
  list: {
    flex: 1,
  },
  cardWrap: {
    marginBottom: s(4),
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
    marginBottom: s(4),
  },
  footer: {
    paddingBottom: s(6),
  },
  footerText: {
    marginBottom: s(3),
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
});
