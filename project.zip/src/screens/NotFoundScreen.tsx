import React from 'react';
import { Platform, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { AppText } from '../components/AppText';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function NotFoundScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.content}>
        <AppText variant="subtitle" style={styles.text}>Screen not found</AppText>
        <Pressable onPress={() => navigation.goBack()} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.btn, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <AppText variant="body" style={styles.btnText}>Go Back</AppText>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: s(4) },
  text: { color: colors.textPrimary },
  btn: { marginTop: s(4), paddingHorizontal: s(6), paddingVertical: s(3), borderRadius: s(2), backgroundColor: colors.primary, minHeight: s(12), alignItems: 'center', justifyContent: 'center' },
  btnText: { color: colors.textInverse, fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  pressed: { opacity: 0.7 },
});
