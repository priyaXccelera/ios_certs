export const s = (n: number) => n * 4;

export const spacing = {
  xs: s(1),
  sm: s(2),
  md: s(4),
  lg: s(6),
  xl: s(8),
  xxl: s(12),
} as const;
