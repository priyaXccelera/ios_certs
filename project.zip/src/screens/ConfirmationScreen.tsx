import { Ionicons } from '@expo/vector-icons';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { formatMoney } from '../data/mockData';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ConfirmationScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'Confirmation'>>();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Confirmation'>>();
  const { appointments, services, staffMembers, locations } = useAppData();
  const appointment = appointments.find((item) => item.id === route.params.appointmentId);
  const service = services.find((item) => item.id === appointment?.serviceId);
  const staff = staffMembers.find((item) => item.id === appointment?.staffId);
  const location = locations.find((item) => item.id === appointment?.locationId);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Confirmed" subtitle="Appointment booked immediately" onBack={() => navigation.navigate('MainTabs')} />
      <View style={styles.content}>
        <View style={styles.icon}><Ionicons name="checkmark" size={s(12)} color={colors.textInverse} /></View>
        <AppText variant="title" style={styles.title}>You're all set</AppText>
        <View style={styles.card}>
          <AppText variant="subtitle">{service?.name ?? 'Appointment'}</AppText>
          <AppText variant="body" style={styles.detail}>{appointment ? new Date(appointment.startIso).toLocaleString() : 'Time unavailable'}</AppText>
          <AppText variant="body" style={styles.detail}>{staff?.name ?? 'Staff'} at {location?.name ?? 'Location'}</AppText>
          <AppText variant="subtitle" style={styles.price}>{formatMoney(appointment?.priceCents ?? 0)}</AppText>
        </View>
        <PrimaryButton label="View all appointments" onPress={() => navigation.navigate('Appointments')} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  content: { flex: 1, padding: s(4), alignItems: 'center', justifyContent: 'center' },
  icon: { width: s(24), height: s(24), borderRadius: s(12), backgroundColor: colors.success, alignItems: 'center', justifyContent: 'center', marginBottom: s(6) },
  title: { textAlign: 'center', marginBottom: s(4) },
  card: { alignSelf: 'stretch', backgroundColor: colors.surface, borderRadius: s(3), padding: s(4), marginBottom: s(6), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  detail: { marginTop: s(2), color: colors.textSecondary },
  price: { color: colors.primary, marginTop: s(3) },
});
