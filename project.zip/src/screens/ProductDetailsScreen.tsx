import React from 'react';
import { Pressable, StyleSheet, Text, View, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { products } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Props = NativeStackScreenProps<RootStackParamList, 'ProductDetails'>;

export default function ProductDetailsScreen({ route, navigation }: Props) {
  const product = products.find((p) => p.id === route.params.id);

  if (!product) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>Product not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>{product.name}</Text>
      <Text style={styles.subtitle}>{product.brand}</Text>
      <Text style={styles.price}>${product.price}</Text>
      <View style={styles.actions}>
        <Pressable
          onPress={() => navigation.navigate('Cart')}
          android_ripple={{ color: 'rgba(255,255,255,0.2)' }}
          style={({ pressed }) => [styles.primaryBtn, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
        >
          <Text style={styles.primaryBtnText}>Add to Cart</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: s(4) },
  title: {
    fontSize: 24,
    color: colors.textPrimary,
    fontWeight: '700',
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
  subtitle: {
    marginTop: s(1),
    color: colors.textSecondary,
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
  price: {
    marginTop: s(3),
    fontSize: 20,
    color: colors.primary,
    fontWeight: '700',
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
  actions: { marginTop: s(6) },
  primaryBtn: {
    backgroundColor: colors.primary,
    borderRadius: s(2),
    paddingVertical: s(3),
    alignItems: 'center',
  },
  primaryBtnText: {
    color: colors.textInverse,
    fontWeight: '600',
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
});