import React, { useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { resources } from '../data/mockData';

export default function ResourcesScreen() {
  const [selectedId, setSelectedId] = useState(resources[0]?.id ?? '');

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <SectionHeader title="Resources" subtitle="Guides, templates, and reports to launch faster." />
      <FlatList
        data={resources}
        style={styles.list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const isActive = item.id === selectedId;
          return (
            <Pressable
              onPress={() => setSelectedId(item.id)}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.resourceCard, isActive && styles.resourceActive, pressed && Platform.OS === 'ios' && styles.pressed]}
            >
              <Text style={[styles.resourceCategory, isActive && styles.resourceCategoryActive]}>{item.category}</Text>
              <Text style={styles.resourceTitle}>{item.title}</Text>
              <Text style={styles.resourceSummary}>{item.summary}</Text>
            </Pressable>
          );
        }}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    paddingTop: s(5),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  resourceCard: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  resourceActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight,
  },
  pressed: {
    opacity: 0.7,
  },
  resourceCategory: {
    fontSize: 11,
    fontWeight: '600',
    lineHeight: 11 * 1.2,
    letterSpacing: 1.2,
    color: colors.textSecondary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
  resourceCategoryActive: {
    color: colors.primaryDark,
  },
  resourceTitle: {
    marginTop: s(2),
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 15 * 1.2,
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  resourceSummary: {
    marginTop: s(2),
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  separator: {
    height: s(4),
  },
});
