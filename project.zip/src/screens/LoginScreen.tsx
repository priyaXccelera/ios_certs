import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { InputField } from '../components/InputField';
import { PrimaryButton } from '../components/PrimaryButton';
import { OutlineButton } from '../components/OutlineButton';
import { InlineLink } from '../components/InlineLink';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (!email.includes('@') || password.length < 6) {
      setError('Enter a valid email and password.');
      setMessage('');
      return;
    }
    setError('');
    setMessage('Welcome back. Redirecting to your dashboard.');
  };

  const handleForgot = () => {
    setMessage('Password reset link sent to your email.');
    setError('');
  };

  const handleGoogle = () => {
    setMessage('Google sign-in requested.');
    setError('');
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <SectionHeader title="Login" subtitle="Access your Circle workspace." />
        <InputField
          label="Email"
          value={email}
          placeholder="you@company.com"
          onChangeText={setEmail}
          error={error ? ' ' : undefined}
        />
        <InputField
          label="Password"
          value={password}
          placeholder="Minimum 6 characters"
          onChangeText={setPassword}
          error={error ? ' ' : undefined}
          secureTextEntry
        />
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
        {message ? <Text style={styles.successText}>{message}</Text> : null}
        <InlineLink label="Forgot Password" onPress={handleForgot} />
        <View style={styles.buttonStack}>
          <PrimaryButton label="Login" onPress={handleLogin} />
          <View style={styles.buttonSpacer} />
          <OutlineButton label="Sign in with Google" onPress={handleGoogle} />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  container: {
    flex: 1,
    paddingTop: s(5),
  },
  buttonStack: {
    marginTop: s(2),
  },
  buttonSpacer: {
    height: s(3),
  },
  errorText: {
    marginBottom: s(2),
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 12 * 1.4,
    letterSpacing: 0.2,
    color: colors.error,
    fontFamily: 'Inter-Regular',
  },
  successText: {
    marginBottom: s(2),
    fontSize: 12,
    fontWeight: '600',
    lineHeight: 12 * 1.4,
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-SemiBold',
  },
});
