export type AppointmentStatus = 'confirmed' | 'cancelled' | 'completed' | 'noShow';
export type DayKey = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';

export interface Location {
  id: string;
  name: string;
  city: string;
  timezone: string;
  address: string;
}

export interface Service {
  id: string;
  name: string;
  durationMinutes: number;
  priceCents: number;
  staffIds: string[];
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  locationId: string;
  serviceIds: string[];
}

export interface TimeBlock {
  start: string;
  end: string;
}

export interface WeeklySchedule {
  staffId: string;
  days: Record<DayKey, TimeBlock[]>;
}

export interface ScheduleOverride {
  id: string;
  staffId: string;
  date: string;
  type: 'dayOff' | 'customHours';
  blocks: TimeBlock[];
  note: string;
}

export interface Appointment {
  id: string;
  customerName: string;
  customerEmail: string;
  locationId: string;
  serviceId: string;
  staffId: string;
  startIso: string;
  endIso: string;
  status: AppointmentStatus;
  priceCents: number;
}

export interface WaitlistEntry {
  id: string;
  customerName: string;
  customerEmail: string;
  locationId: string;
  serviceId: string;
  staffId?: string;
  date: string;
  createdAtIso: string;
  notified: boolean;
}
