import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { AppText } from '../components/AppText';
import { PrimaryButton } from '../components/PrimaryButton';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function AuthScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Auth'>>();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submit = () => {
    if (mode === 'signup' && name.trim().length === 0) {
      setName('New Team Member');
    }
    if (email.trim().length === 0) {
      setEmail('person@example.com');
    }
    if (password.trim().length === 0) {
      setPassword('password');
    }
    navigation.replace('MainTabs');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="light" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.hero}>
          <View style={styles.logo}><AppText variant="subtitle" style={styles.logoText}>SSO</AppText></View>
          <AppText variant="title" style={styles.title}>Appointments made simple</AppText>
          <AppText variant="body" style={styles.subtitle}>Book visits, manage staff hours, and keep every location running smoothly.</AppText>
        </View>
        <View style={styles.card}>
          <View style={styles.switchRow}>
            <Pressable onPress={() => setMode('login')} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.switchButton, mode === 'login' && styles.switchActive, pressed && Platform.OS === 'ios' && styles.pressed]}>
              <AppText variant="caption" style={[styles.switchText, mode === 'login' && styles.switchTextActive]}>SIGN IN</AppText>
            </Pressable>
            <Pressable onPress={() => setMode('signup')} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.switchButton, mode === 'signup' && styles.switchActive, pressed && Platform.OS === 'ios' && styles.pressed]}>
              <AppText variant="caption" style={[styles.switchText, mode === 'signup' && styles.switchTextActive]}>CREATE ACCOUNT</AppText>
            </Pressable>
          </View>
          {mode === 'signup' ? (
            <TextInput value={name} onChangeText={setName} placeholder="Full name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          ) : null}
          <TextInput value={email} onChangeText={setEmail} placeholder="Email address" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={password} onChangeText={setPassword} placeholder="Password" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} secureTextEntry returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <PrimaryButton label={mode === 'login' ? 'Sign in' : 'Create account'} onPress={submit} />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.primaryDark, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1, justifyContent: 'center', padding: s(4) },
  hero: { marginBottom: s(8) },
  logo: { width: s(16), height: s(16), borderRadius: s(4), backgroundColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginBottom: s(4) },
  logoText: { color: colors.textInverse },
  title: { color: colors.textInverse },
  subtitle: { color: colors.primaryLight, marginTop: s(3) },
  card: { backgroundColor: colors.surface, borderRadius: s(3), padding: s(4), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(2) }, shadowOpacity: 0.12, shadowRadius: s(3) }, android: { elevation: 8 }, default: {} }) },
  switchRow: { flexDirection: 'row', minHeight: s(11), backgroundColor: colors.background, borderRadius: s(2), padding: s(1), marginBottom: s(4) },
  switchButton: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: s(2) },
  switchActive: { backgroundColor: colors.surface },
  switchText: { color: colors.textSecondary, letterSpacing: 1.2 },
  switchTextActive: { color: colors.primary, fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  pressed: { opacity: 0.7 },
});
