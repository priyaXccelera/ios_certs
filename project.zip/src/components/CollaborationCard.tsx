import React from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { CollaborationCard as CollaborationCardType } from '../types';

type CollaborationCardProps = {
  item: CollaborationCardType;
};

export function CollaborationCard({ item }: CollaborationCardProps) {
  return (
    <View style={styles.card}>
      <View style={styles.iconWrap}>
        <MaterialIcons name="hub" size={22} color={colors.primaryDark} />
      </View>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.subtitle}>{item.subtitle}</Text>
      <View style={styles.imagePlaceholder}>
        <MaterialIcons name="image" size={24} color={colors.textDisabled} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: s(56),
    marginRight: s(4),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.12,
        shadowRadius: 6,
      },
      android: { elevation: 5 },
      default: {},
    }),
  },
  iconWrap: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    marginTop: s(3),
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 14 * 1.2,
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  subtitle: {
    marginTop: s(2),
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 12 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  imagePlaceholder: {
    marginTop: s(3),
    height: s(20),
    borderRadius: s(2),
    backgroundColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
