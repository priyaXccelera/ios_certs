import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { HeaderBar } from '../components/HeaderBar';
import { SearchField } from '../components/SearchField';
import { initialWishlistItems, products } from '../data/mockData';
import { WishlistItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { RootStackParamList } from '../navigation';

type WishlistNavigation = NativeStackNavigationProp<RootStackParamList, 'MainTabs'>;

export default function WishlistScreen() {
  const navigation = useNavigation<WishlistNavigation>();
  const [items, setItems] = useState<WishlistItem[]>(initialWishlistItems);
  const [query, setQuery] = useState('');

  const rows = useMemo(() => items.map((item) => ({ item, product: products.find((product) => product.id === item.productId) ?? products[0] })).filter((row) => `${row.product.name} ${row.product.brand}`.toLowerCase().includes(query.toLowerCase())), [items, query]);

  const remove = (id: string) => setItems((prev) => prev.filter((item) => item.id !== id));
  const moveToCart = (id: string) => {
    remove(id);
    Alert.alert('Moved to cart', 'This saved product is ready for checkout.');
  };

  const renderRow = ({ item }: { item: { item: WishlistItem; product: typeof products[number] } }) => (
    <View style={styles.card}>
      <Pressable onPress={() => navigation.navigate('ProductDetails', { id: item.product.id })} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [StyleSheet.absoluteFillObject, pressed && Platform.OS === 'ios' && styles.pressed]} />
      <View pointerEvents="none" style={styles.visualRow}>
        <View style={styles.imageBox}><Ionicons name="heart" size={s(8)} color={colors.error} /></View>
        <View style={styles.textWrap}>
          <Text style={styles.brand}>{item.product.brand}</Text>
          <Text style={styles.name}>{item.product.name}</Text>
          <Text style={styles.meta}>Saved {item.item.savedAt}</Text>
          <Text style={styles.price}>${item.product.price}</Text>
        </View>
      </View>
      <View style={styles.actionRow}>
        <Pressable onPress={() => moveToCart(item.item.id)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.smallButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Text style={styles.smallButtonText}>Move</Text>
        </Pressable>
        <Pressable onPress={() => remove(item.item.id)} hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }} android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }} style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Ionicons name="close" size={s(5)} color={colors.textSecondary} />
        </Pressable>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Wishlist" subtitle={`${items.length} saved products`} />
      <View style={styles.searchWrap}><SearchField value={query} onChangeText={setQuery} placeholder="Search saved items" /></View>
      <FlatList
        data={rows}
        keyExtractor={(row) => row.item.id}
        renderItem={renderRow}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={<Text style={styles.emptyText}>Saved products will appear here.</Text>}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}) },
  searchWrap: { paddingHorizontal: s(4), paddingBottom: s(4) },
  listContent: { paddingHorizontal: s(4), paddingBottom: s(8) },
  card: { minHeight: s(34), borderRadius: s(4), backgroundColor: colors.card, overflow: 'hidden', padding: s(3), ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 3 }, default: {} }) },
  visualRow: { flexDirection: 'row', paddingRight: s(22) },
  imageBox: { width: s(24), height: s(24), borderRadius: s(3), backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginRight: s(3) },
  textWrap: { flex: 1 },
  brand: { fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 1.2, textTransform: 'uppercase' },
  name: { marginTop: s(1), fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', color: colors.textPrimary, letterSpacing: 0.2 },
  meta: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  price: { marginTop: s(2), fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  actionRow: { position: 'absolute', right: s(3), top: s(3), bottom: s(3), alignItems: 'center', justifyContent: 'space-between' },
  smallButton: { minHeight: s(9), borderRadius: s(5), paddingHorizontal: s(3), backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  smallButtonText: { fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.textInverse, letterSpacing: 0.2 },
  iconButton: { width: s(9), height: s(9), borderRadius: s(5), backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center' },
  separator: { height: s(3) },
  emptyText: { textAlign: 'center', marginVertical: s(8), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  pressed: { opacity: 0.72 },
});
