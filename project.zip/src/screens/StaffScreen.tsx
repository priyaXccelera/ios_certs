import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { RootStackParamList } from '../navigation';
import { StaffMember } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function StaffScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Staff'>>();
  const { staffMembers, locations, services, addStaffMember, updateStaffMember } = useAppData();
  const [editing, setEditing] = useState<StaffMember | undefined>();
  const [name, setName] = useState('');
  const [role, setRole] = useState('Stylist');
  const [locationId, setLocationId] = useState(locations[0]?.id ?? '');
  const [serviceIds, setServiceIds] = useState<string[]>([]);
  const edit = (item: StaffMember) => { setEditing(item); setName(item.name); setRole(item.role); setLocationId(item.locationId); setServiceIds(item.serviceIds); };
  const toggleService = (id: string) => setServiceIds((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
  const save = () => {
    const staff: StaffMember = { id: editing?.id ?? `staff-${Date.now()}`, name: name.trim() || 'New Staff Member', role: role.trim() || 'Provider', locationId, serviceIds };
    if (editing) updateStaffMember(staff); else addStaffMember(staff);
    setEditing(undefined); setName(''); setRole('Stylist'); setLocationId(locations[0]?.id ?? ''); setServiceIds([]);
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Staff" subtitle="Add or edit staff members" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}>
          <TextInput value={name} onChangeText={setName} placeholder="Staff name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={role} onChangeText={setRole} placeholder="Role" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <AppText variant="label">LOCATION</AppText><View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={item.name} selected={locationId === item.id} onPress={() => setLocationId(item.id)} />)}</View>
          <AppText variant="label">SERVICES</AppText><View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={item.name} selected={serviceIds.includes(item.id)} onPress={() => toggleService(item.id)} />)}</View>
          <PrimaryButton label={editing ? 'Save staff member' : 'Add staff member'} onPress={save} />
        </View>
        <FlatList style={styles.list} data={staffMembers} keyExtractor={(item) => item.id} renderItem={({ item }) => { const location = locations.find((loc) => loc.id === item.locationId); return <Pressable onPress={() => edit(item)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.row, pressed && Platform.OS === 'ios' && styles.pressed]}><AppText variant="subtitle">{item.name}</AppText><AppText variant="caption">{item.role} · {location?.name ?? 'Location'} · {item.serviceIds.length} services</AppText></Pressable>; }} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginTop: s(2), marginBottom: s(2) },
  list: { flex: 1, padding: s(4) },
  row: { minHeight: s(18), padding: s(3), backgroundColor: colors.surface, borderRadius: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  separator: { height: s(2) },
  pressed: { opacity: 0.7 },
});
