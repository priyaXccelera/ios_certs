import React, { useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { PricingCard } from '../components/PricingCard';
import { SectionHeader } from '../components/SectionHeader';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { plans } from '../data/mockData';

export default function PricingScreen() {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <SectionHeader title="Pricing" subtitle="Flexible plans for scaling engagement." />
      </View>
      <FlatList
        data={plans}
        style={styles.list}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <PricingCard plan={item} onSelect={() => setSelected(item.id)} />
        )}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ListFooterComponent={
          <View style={styles.footer}>
            {selected ? (
              <Text style={styles.successText}>Plan selected. Our team will guide your next steps.</Text>
            ) : (
              <Text style={styles.footerText}>Select a plan to unlock onboarding and tailored support.</Text>
            )}
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  header: {
    paddingTop: s(5),
    marginBottom: s(4),
  },
  list: {
    flex: 1,
  },
  footer: {
    paddingBottom: s(6),
  },
  footerText: {
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  successText: {
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-SemiBold',
  },
});
