import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator, DrawerContentComponentProps, DrawerContentScrollView, DrawerNavigationOptions, useDrawerProgress } from '@react-navigation/drawer';
import Animated, { interpolate, useAnimatedStyle } from 'react-native-reanimated';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import HomeScreen from '../screens/HomeScreen';
import FeaturesScreen from '../screens/FeaturesScreen';
import PricingScreen from '../screens/PricingScreen';
import TestimonialsScreen from '../screens/TestimonialsScreen';
import ResourcesScreen from '../screens/ResourcesScreen';
import CompanyScreen from '../screens/CompanyScreen';
import ContactScreen from '../screens/ContactScreen';
import LoginScreen from '../screens/LoginScreen';
import NotFoundScreen from '../screens/NotFoundScreen';
import { DrawerLink } from '../components/DrawerLink';

export type DrawerParamList = {
  Home: undefined;
  Features: undefined;
  Pricing: undefined;
  Testimonials: undefined;
  Resources: undefined;
  Company: undefined;
  Contact: undefined;
  Login: undefined;
};

export type RootStackParamList = {
  Main: undefined;
  NotFound: undefined;
};

const Drawer = createDrawerNavigator<DrawerParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

function CustomDrawerContent(props: DrawerContentComponentProps) {
  const progress = useDrawerProgress();
  const drawerShift = s(6);
  const animatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(progress.value, [0, 1], [0, 1]),
    transform: [{ translateX: interpolate(progress.value, [0, 1], [-drawerShift, 0]) }],
  }));

  const activeRoute = props.state.routeNames[props.state.index] as keyof DrawerParamList;

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={styles.drawerContent}>
      <Animated.View style={animatedStyle}>
        <View style={styles.drawerHeader}>
          <Text style={styles.drawerTitle}>Circle</Text>
          <Text style={styles.drawerSubtitle}>Engagement Platform</Text>
        </View>
        <DrawerLink label="Features" icon="auto-awesome" active={activeRoute === 'Features'} onPress={() => props.navigation.navigate('Features')} />
        <DrawerLink label="Pricing" icon="payments" active={activeRoute === 'Pricing'} onPress={() => props.navigation.navigate('Pricing')} />
        <DrawerLink label="Testimonials" icon="star" active={activeRoute === 'Testimonials'} onPress={() => props.navigation.navigate('Testimonials')} />
        <DrawerLink label="Resources" icon="library-books" active={activeRoute === 'Resources'} onPress={() => props.navigation.navigate('Resources')} />
        <DrawerLink label="Company" icon="business" active={activeRoute === 'Company'} onPress={() => props.navigation.navigate('Company')} />
        <DrawerLink label="Contact" icon="mail" active={activeRoute === 'Contact'} onPress={() => props.navigation.navigate('Contact')} />
        <DrawerLink label="Login" icon="lock" active={activeRoute === 'Login'} onPress={() => props.navigation.navigate('Login')} />
      </Animated.View>
    </DrawerContentScrollView>
  );
}

function DrawerNavigator() {
  const screenOptions: DrawerNavigationOptions = {
    headerShown: false,
    drawerType: 'slide',
    overlayColor: 'rgba(17,17,17,0.4)',
    drawerStyle: {
      backgroundColor: colors.surface,
      width: s(68),
    },
    sceneContainerStyle: {
      backgroundColor: colors.background,
    },
  };

  return (
    <Drawer.Navigator screenOptions={screenOptions} drawerContent={(props) => <CustomDrawerContent {...props} />}>
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Features" component={FeaturesScreen} />
      <Drawer.Screen name="Pricing" component={PricingScreen} />
      <Drawer.Screen name="Testimonials" component={TestimonialsScreen} />
      <Drawer.Screen name="Resources" component={ResourcesScreen} />
      <Drawer.Screen name="Company" component={CompanyScreen} />
      <Drawer.Screen name="Contact" component={ContactScreen} />
      <Drawer.Screen name="Login" component={LoginScreen} />
    </Drawer.Navigator>
  );
}

export function RootNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="Main"
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
          ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }),
        },
        headerTitleStyle: {
          fontFamily: 'Inter-SemiBold',
          fontWeight: '600',
          fontSize: 17,
          color: colors.textPrimary,
          letterSpacing: Platform.select({ ios: -0.4, android: 0, default: 0 }),
        } as any,
        headerTintColor: colors.primary,
        headerBackTitleVisible: false,
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen name="Main" component={DrawerNavigator} options={{ headerShown: false }} />
      <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Not Found' }} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  drawerContent: {
    paddingTop: s(6),
    paddingBottom: s(6),
  },
  drawerHeader: {
    paddingHorizontal: s(4),
    paddingBottom: s(4),
  },
  drawerTitle: {
    fontSize: 20,
    fontWeight: '700',
    lineHeight: 20 * 1.2,
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  drawerSubtitle: {
    marginTop: s(1),
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 12 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
});
