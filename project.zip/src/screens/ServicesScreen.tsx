import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { formatMoney } from '../data/mockData';
import { RootStackParamList } from '../navigation';
import { Service } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ServicesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Services'>>();
  const { services, staffMembers, addService, updateService } = useAppData();
  const [editing, setEditing] = useState<Service | undefined>();
  const [name, setName] = useState('');
  const [duration, setDuration] = useState('45');
  const [price, setPrice] = useState('49.99');
  const [selectedStaff, setSelectedStaff] = useState<string[]>([]);
  const edit = (item: Service) => { setEditing(item); setName(item.name); setDuration(String(item.durationMinutes)); setPrice((item.priceCents / 100).toFixed(2)); setSelectedStaff(item.staffIds); };
  const toggleStaff = (id: string) => setSelectedStaff((prev) => prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]);
  const save = () => {
    const priceCents = Math.round(Number(price.replace(/[^0-9.]/g, '')) * 100);
    const service: Service = { id: editing?.id ?? `svc-${Date.now()}`, name: name.trim() || 'New Service', durationMinutes: Number(duration) || 30, priceCents: Number.isFinite(priceCents) ? priceCents : 0, staffIds: selectedStaff };
    if (editing) updateService(service); else addService(service);
    setEditing(undefined); setName(''); setDuration('45'); setPrice('49.99'); setSelectedStaff([]);
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Services" subtitle="Prices, durations, and trained staff" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}>
          <TextInput value={name} onChangeText={setName} placeholder="Service name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={duration} onChangeText={setDuration} placeholder="Duration minutes" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="number-pad" returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={price} onChangeText={setPrice} placeholder="Price" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="decimal-pad" returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <View style={styles.wrap}>{staffMembers.map((item) => <Chip key={item.id} label={item.name} selected={selectedStaff.includes(item.id)} onPress={() => toggleStaff(item.id)} />)}</View>
          <PrimaryButton label={editing ? 'Save service' : 'Add service'} onPress={save} />
        </View>
        <FlatList style={styles.list} data={services} keyExtractor={(item) => item.id} renderItem={({ item }) => <Pressable onPress={() => edit(item)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.row, pressed && Platform.OS === 'ios' && styles.pressed]}><AppText variant="subtitle">{item.name}</AppText><AppText variant="caption">{item.durationMinutes} min · {formatMoney(item.priceCents)} · {item.staffIds.length} trained</AppText></Pressable>} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: s(2) },
  list: { flex: 1, padding: s(4) },
  row: { minHeight: s(18), padding: s(3), backgroundColor: colors.surface, borderRadius: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  separator: { height: s(2) },
  pressed: { opacity: 0.7 },
});
