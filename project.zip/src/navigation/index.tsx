import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import AppointmentDetailScreen from '../screens/AppointmentDetailScreen';
import AppointmentsScreen from '../screens/AppointmentsScreen';
import AuthScreen from '../screens/AuthScreen';
import BookScreen from '../screens/BookScreen';
import ConfirmationScreen from '../screens/ConfirmationScreen';
import DashboardScreen from '../screens/DashboardScreen';
import LocationsScreen from '../screens/LocationsScreen';
import ManageScreen from '../screens/ManageScreen';
import NotFoundScreen from '../screens/NotFoundScreen';
import ServicesScreen from '../screens/ServicesScreen';
import StaffHoursScreen from '../screens/StaffHoursScreen';
import StaffScreen from '../screens/StaffScreen';
import WaitlistScreen from '../screens/WaitlistScreen';
import { colors } from '../theme/colors';

export type RootStackParamList = {
  Auth: undefined;
  MainTabs: undefined;
  Dashboard: undefined;
  Book: undefined;
  Confirmation: { appointmentId: string };
  Appointments: { filter?: 'all' | 'confirmed' | 'cancelled' | 'completed' | 'noShow' } | undefined;
  AppointmentDetail: { id: string };
  Manage: undefined;
  Locations: undefined;
  Services: undefined;
  Staff: undefined;
  StaffHours: { staffId?: string } | undefined;
  Waitlist: undefined;
  NotFound: undefined;
};

type TabParamList = {
  Dashboard: undefined;
  Book: undefined;
  Appointments: undefined;
  Manage: undefined;
  Waitlist: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ color, size }) => {
          const icon = route.name === 'Dashboard' ? 'grid' : route.name === 'Book' ? 'calendar' : route.name === 'Appointments' ? 'list' : route.name === 'Manage' ? 'settings' : 'notifications';
          return <Ionicons name={icon} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Book" component={BookScreen} />
      <Tab.Screen name="Appointments" component={AppointmentsScreen} />
      <Tab.Screen name="Manage" component={ManageScreen} />
      <Tab.Screen name="Waitlist" component={WaitlistScreen} />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="Auth"
      screenOptions={{
        headerShown: false,
        headerStyle: { backgroundColor: colors.surface, ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }) },
        headerTitleStyle: { fontFamily: Platform.select({ ios: 'Inter-SemiBold', android: 'Inter-SemiBold', default: 'Inter-SemiBold' }), fontWeight: '600', fontSize: 17, color: colors.textPrimary },
        headerTintColor: colors.primary,
        headerBackTitleVisible: false,
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen name="Auth" component={AuthScreen} />
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen name="Dashboard" component={DashboardScreen} />
      <Stack.Screen name="Book" component={BookScreen} />
      <Stack.Screen name="Confirmation" component={ConfirmationScreen} />
      <Stack.Screen name="Appointments" component={AppointmentsScreen} />
      <Stack.Screen name="AppointmentDetail" component={AppointmentDetailScreen} />
      <Stack.Screen name="Manage" component={ManageScreen} />
      <Stack.Screen name="Locations" component={LocationsScreen} />
      <Stack.Screen name="Services" component={ServicesScreen} />
      <Stack.Screen name="Staff" component={StaffScreen} />
      <Stack.Screen name="StaffHours" component={StaffHoursScreen} />
      <Stack.Screen name="Waitlist" component={WaitlistScreen} />
      <Stack.Screen name="NotFound" component={NotFoundScreen} />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: colors.surface,
    borderTopColor: colors.border,
    borderTopWidth: StyleSheet.hairlineWidth,
    height: Platform.select({ ios: 83, android: 60, default: 60 }),
    paddingBottom: Platform.select({ ios: 28, android: 8, default: 8 }),
    paddingTop: 8,
    ...Platform.select({ android: { elevation: 8 }, ios: {}, default: {} }),
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '500',
    fontFamily: Platform.select({ ios: 'Inter-Medium', android: 'Inter-Medium', default: 'Inter-Medium' }),
    letterSpacing: 0.2,
  },
});
