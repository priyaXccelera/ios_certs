import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppText } from '../components/AppText';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { RootStackParamList } from '../navigation';
import { Location } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function LocationsScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Locations'>>();
  const { locations, addLocation, updateLocation } = useAppData();
  const [editing, setEditing] = useState<Location | undefined>();
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [timezone, setTimezone] = useState('America/Chicago');
  const [address, setAddress] = useState('');
  const edit = (item: Location) => { setEditing(item); setName(item.name); setCity(item.city); setTimezone(item.timezone); setAddress(item.address); };
  const save = () => {
    const location: Location = { id: editing?.id ?? `loc-${Date.now()}`, name: name.trim() || 'New Location', city: city.trim() || 'City', timezone: timezone.trim() || 'America/Chicago', address: address.trim() || 'Address' };
    if (editing) updateLocation(location); else addLocation(location);
    setEditing(undefined); setName(''); setCity(''); setTimezone('America/Chicago'); setAddress('');
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Locations" subtitle="Add or edit locations" onBack={() => navigation.goBack()} />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <View style={styles.form}>
          <TextInput value={name} onChangeText={setName} placeholder="Location name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={city} onChangeText={setCity} placeholder="City" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={timezone} onChangeText={setTimezone} placeholder="Timezone" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <TextInput value={address} onChangeText={setAddress} placeholder="Address" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
          <PrimaryButton label={editing ? 'Save location' : 'Add location'} onPress={save} />
        </View>
        <FlatList style={styles.list} data={locations} keyExtractor={(item) => item.id} renderItem={({ item }) => <Pressable onPress={() => edit(item)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.row, pressed && Platform.OS === 'ios' && styles.pressed]}><AppText variant="subtitle">{item.name}</AppText><AppText variant="caption">{item.city} · {item.timezone} · {item.address}</AppText></Pressable>} ItemSeparatorComponent={() => <View style={styles.separator} />} showsVerticalScrollIndicator={false} removeClippedSubviews={Platform.OS === 'android'} initialNumToRender={10} maxToRenderPerBatch={10} windowSize={5} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  form: { padding: s(4), backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  list: { flex: 1, padding: s(4) },
  row: { minHeight: s(18), padding: s(3), backgroundColor: colors.surface, borderRadius: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  separator: { height: s(2) },
  pressed: { opacity: 0.7 },
});
