import React from 'react';
import { Pressable, StyleSheet, Text, Platform, ViewStyle } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type OutlineButtonProps = {
  label: string;
  onPress: () => void;
  style?: ViewStyle;
};

export function OutlineButton({ label, onPress, style }: OutlineButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.button, style, pressed && Platform.OS === 'ios' && styles.pressed]}
    >
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: s(2),
    paddingVertical: s(3),
    paddingHorizontal: s(5),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.surface,
  },
  pressed: {
    opacity: 0.7,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 14 * 1.2,
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
});
