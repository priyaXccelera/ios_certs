export type Feature = {
  id: string;
  title: string;
  description: string;
  icon: string;
};

export type Testimonial = {
  id: string;
  name: string;
  company: string;
  rating: number;
  message: string;
};

export type Plan = {
  id: string;
  name: string;
  price: string;
  highlight: boolean;
  features: string[];
};

export type CollaborationCard = {
  id: string;
  title: string;
  subtitle: string;
};

export type ResourceItem = {
  id: string;
  title: string;
  category: string;
  summary: string;
};

export type CompanyValue = {
  id: string;
  title: string;
  detail: string;
};
