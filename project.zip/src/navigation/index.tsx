import React from 'react';
import { Platform } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';
import DiscoverScreen from '../screens/DiscoverScreen';
import ProductDetailsScreen from '../screens/ProductDetailsScreen';
import CartScreen from '../screens/CartScreen';

export type RootStackParamList = {
  Discover: undefined;
  ProductDetails: { id: string };
  Cart: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export function RootNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="Discover"
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
          ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }),
        },
        headerTintColor: colors.primary,
        headerTitleStyle: {
          color: colors.textPrimary,
          fontWeight: '600',
          fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
        },
      }}
    >
      <Stack.Screen name="Discover" component={DiscoverScreen} />
      <Stack.Screen name="ProductDetails" component={ProductDetailsScreen} options={{ title: 'Product Details' }} />
      <Stack.Screen name="Cart" component={CartScreen} />
    </Stack.Navigator>
  );
}