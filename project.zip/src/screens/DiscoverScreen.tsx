import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Platform, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { ProductCard } from '../components/ProductCard';
import { SearchField } from '../components/SearchField';
import { categories, products } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { Product, ProductCategory } from '../types';
import { RootStackParamList } from '../navigation';

type DiscoverNavigation = NativeStackNavigationProp<RootStackParamList, 'MainTabs'>;

export default function DiscoverScreen() {
  const navigation = useNavigation<DiscoverNavigation>();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('All');
  const [savedIds, setSavedIds] = useState<string[]>(['p5', 'p9', 'p11']);
  const [refreshing, setRefreshing] = useState(false);

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      const text = `${product.name} ${product.brand} ${product.category}`.toLowerCase();
      return matchesCategory && text.includes(query.toLowerCase());
    });
  }, [query, selectedCategory]);

  const trending = filteredProducts.filter((product) => product.trending);
  const recommended = filteredProducts.filter((product) => product.recommended);

  const toggleSave = (id: string) => {
    setSavedIds((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
    Alert.alert('Wishlist updated', 'Your saved items have been refreshed locally.');
  };

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 700);
  };

  const renderProduct = ({ item }: { item: Product }) => (
    <ProductCard
      product={item}
      onPress={() => navigation.navigate('ProductDetails', { id: item.id })}
      onSave={() => toggleSave(item.id)}
      saved={savedIds.includes(item.id)}
    />
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={recommended}
        keyExtractor={(item) => item.id}
        renderItem={renderProduct}
        numColumns={2}
        columnWrapperStyle={styles.gridRow}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        ItemSeparatorComponent={() => <View style={styles.listGap} />}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.primary} />}
        ListHeaderComponent={
          <View style={styles.headerContent}>
            <Text style={styles.kicker}>SUKHMEET STORE</Text>
            <Text style={styles.title}>Discover</Text>
            <Text style={styles.subtitle}>Premium finds curated for your iPhone lifestyle.</Text>
            <SearchField value={query} onChangeText={setQuery} placeholder="Search products, brands, categories" />
            <LinearGradient colors={[colors.primary, colors.primaryDark]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.banner}>
              <View style={styles.bannerTextWrap}>
                <Text style={styles.bannerLabel}>Summer edit</Text>
                <Text style={styles.bannerTitle}>Up to 30% off travel essentials</Text>
                <Text style={styles.bannerText}>Mock checkout, wishlist and cart workflows included.</Text>
              </View>
              <Ionicons name="sparkles" size={s(12)} color={colors.textInverse} />
            </LinearGradient>
            <ScrollView horizontal directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
              {categories.map((category) => (
                <Pressable
                  key={category}
                  onPress={() => setSelectedCategory(category)}
                  android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
                  style={({ pressed }) => [styles.chip, selectedCategory === category && styles.chipActive, pressed && Platform.OS === 'ios' && styles.pressed]}
                >
                  <Text style={[styles.chipText, selectedCategory === category && styles.chipTextActive]}>{category}</Text>
                </Pressable>
              ))}
            </ScrollView>
            <Text style={styles.sectionTitle}>Trending now</Text>
            <ScrollView horizontal directionalLockEnabled decelerationRate="fast" showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalProducts}>
              {trending.map((item) => (
                <ProductCard key={item.id} product={item} compact onPress={() => navigation.navigate('ProductDetails', { id: item.id })} onSave={() => toggleSave(item.id)} saved={savedIds.includes(item.id)} />
              ))}
            </ScrollView>
            <Text style={styles.sectionTitle}>Recommended for you</Text>
          </View>
        }
        ListEmptyComponent={<Text style={styles.emptyText}>No products match your search.</Text>}
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}),
  },
  headerContent: {
    paddingHorizontal: s(4),
    paddingTop: s(4),
  },
  kicker: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    color: colors.primary,
    letterSpacing: 1.2,
  },
  title: {
    marginTop: s(1),
    fontFamily: 'Inter-Bold',
    fontSize: s(9),
    lineHeight: s(9) * 1.2,
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    marginBottom: s(4),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '400',
    color: colors.textSecondary,
    letterSpacing: 0.2,
  },
  banner: {
    marginTop: s(4),
    borderRadius: s(4),
    padding: s(5),
    minHeight: s(36),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bannerTextWrap: {
    flex: 1,
    paddingRight: s(3),
  },
  bannerLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    color: colors.textInverse,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  bannerTitle: {
    marginTop: s(2),
    fontFamily: 'Inter-Bold',
    fontSize: s(6),
    lineHeight: s(6) * 1.2,
    fontWeight: '700',
    color: colors.textInverse,
    letterSpacing: -0.5,
  },
  bannerText: {
    marginTop: s(2),
    fontFamily: 'Inter-Regular',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '400',
    color: colors.textInverse,
    letterSpacing: 0.2,
  },
  chipRow: {
    paddingVertical: s(4),
  },
  chip: {
    minHeight: s(10),
    borderRadius: s(5),
    paddingHorizontal: s(4),
    marginRight: s(2),
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  chipActive: {
    backgroundColor: colors.textPrimary,
    borderColor: colors.textPrimary,
  },
  chipText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: s(3),
    lineHeight: s(3) * 1.4,
    fontWeight: '600',
    color: colors.textSecondary,
    letterSpacing: 0.2,
  },
  chipTextActive: {
    color: colors.textInverse,
  },
  pressed: {
    opacity: 0.72,
  },
  sectionTitle: {
    marginBottom: s(3),
    fontFamily: 'Inter-Bold',
    fontSize: s(6),
    lineHeight: s(6) * 1.2,
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  horizontalProducts: {
    paddingBottom: s(5),
  },
  gridRow: {
    paddingHorizontal: s(4),
    justifyContent: 'space-between',
  },
  listGap: {
    height: s(4),
  },
  listContent: {
    paddingBottom: s(8),
  },
  emptyText: {
    margin: s(4),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '400',
    color: colors.textSecondary,
    letterSpacing: 0.2,
  },
});
