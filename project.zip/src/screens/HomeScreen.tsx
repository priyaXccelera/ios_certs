import React, { useEffect } from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import Animated, { interpolate, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { CollaborationCard } from '../components/CollaborationCard';
import { SectionHeader } from '../components/SectionHeader';
import { FeatureCard } from '../components/FeatureCard';
import { Chip } from '../components/Chip';
import { StatCard } from '../components/StatCard';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { collaborationCards, features } from '../data/mockData';
import { DrawerParamList } from '../navigation';

export default function HomeScreen() {
  const navigation = useNavigation<DrawerNavigationProp<DrawerParamList, 'Home'>>();

  const heroProgress = useSharedValue(0);
  const floatProgress = useSharedValue(0);
  const heroOffset = s(6);
  const floatRange = s(2);

  useEffect(() => {
    heroProgress.value = withTiming(1, { duration: 650 });
    floatProgress.value = withRepeat(withTiming(1, { duration: 2200 }), -1, true);
  }, [heroProgress, floatProgress]);

  const heroStyle = useAnimatedStyle(() => ({
    opacity: heroProgress.value,
    transform: [{ translateY: interpolate(heroProgress.value, [0, 1], [heroOffset, 0]) }],
  }));

  const floatStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: interpolate(floatProgress.value, [0, 1], [0, -floatRange]) }],
  }));

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        stickyHeaderIndices={[0]}
        showsVerticalScrollIndicator={false}
      >
        <HeaderBar title="Circle" onMenuPress={() => navigation.openDrawer()} />
        <Animated.View style={[styles.hero, heroStyle]}>
          <Chip label="Premium Analytics" />
          <Text style={styles.heroTitle}>A powerful online engagement tool that's intuitive and simple to use.</Text>
          <Text style={styles.heroSubtitle}>
            With stellar one-click reports and unmatched support, see how Circle can make a difference in your business.
          </Text>
          <PrimaryButton label="Get Started Free" onPress={() => navigation.navigate('Pricing')} />
          <View style={styles.statsRow}>
            <StatCard label="Engagement Lift" value="+38%" />
            <View style={styles.statSpacer} />
            <StatCard label="Reports" value="1-Click" />
          </View>
        </Animated.View>
        <View style={styles.section}>
          <SectionHeader title="Collaboration" subtitle="Premium experiences for modern teams." />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            directionalLockEnabled
            decelerationRate="fast"
            contentContainerStyle={styles.horizontalContent}
          >
            {collaborationCards.map((item) => (
              <Animated.View key={item.id} style={floatStyle}>
                <CollaborationCard item={item} />
              </Animated.View>
            ))}
          </ScrollView>
        </View>
        <View style={styles.section}>
          <SectionHeader title="Core Features" subtitle="Analytics, community, and automation at scale." />
          {features.map((feature) => (
            <View key={feature.id} style={styles.featureWrap}>
              <FeatureCard feature={feature} />
            </View>
          ))}
        </View>
        <View style={styles.section}>
          <SectionHeader title="Launch faster" subtitle="Everything you need for a bold SaaS rollout." />
          <View style={styles.highlightCard}>
            <Text style={styles.highlightTitle}>Enterprise-grade controls</Text>
            <Text style={styles.highlightText}>
              Secure workflows, role-based permissions, and compliance ready from day one.
            </Text>
            <PrimaryButton label="Explore Pricing" onPress={() => navigation.navigate('Pricing')} />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  scroll: {
    flex: 1,
  },
  content: {
    paddingBottom: s(6),
  },
  hero: {
    paddingHorizontal: s(4),
    paddingTop: s(5),
  },
  heroTitle: {
    marginTop: s(3),
    fontSize: 26,
    fontWeight: '700',
    lineHeight: 26 * 1.2,
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  heroSubtitle: {
    marginTop: s(3),
    marginBottom: s(4),
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 14 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  statsRow: {
    flexDirection: 'row',
    marginTop: s(4),
  },
  statSpacer: {
    width: s(3),
  },
  section: {
    marginTop: s(6),
    paddingHorizontal: s(4),
  },
  horizontalContent: {
    paddingVertical: s(2),
  },
  featureWrap: {
    marginBottom: s(4),
  },
  highlightCard: {
    backgroundColor: colors.primaryLight,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.primary,
    ...Platform.select({
      ios: {
        shadowColor: colors.primary,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.15,
        shadowRadius: 10,
      },
      android: { elevation: 6 },
      default: {},
    }),
  },
  highlightTitle: {
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 18 * 1.2,
    letterSpacing: -0.5,
    color: colors.textPrimary,
    marginBottom: s(2),
    fontFamily: 'Inter-Bold',
  },
  highlightText: {
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    marginBottom: s(3),
    fontFamily: 'Inter-Regular',
  },
});
