import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type ChipProps = {
  label: string;
};

export function Chip({ label }: ChipProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignSelf: 'flex-start',
    paddingHorizontal: s(3),
    paddingVertical: s(1),
    borderRadius: s(4),
    backgroundColor: colors.accent,
  },
  label: {
    fontSize: 10,
    fontWeight: '600',
    lineHeight: 10 * 1.2,
    letterSpacing: 1.2,
    color: colors.textPrimary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
});
