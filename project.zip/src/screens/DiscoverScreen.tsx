import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { products as seedProducts } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type Props = NativeStackScreenProps<RootStackParamList, 'Discover'>;

export default function DiscoverScreen({ navigation }: Props) {
  const [query, setQuery] = useState('');
  const [items] = useState(seedProducts);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((p) => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q));
  }, [items, query]);

  return (
    <SafeAreaView style={styles.container}>
      <TextInput
        value={query}
        onChangeText={setQuery}
        placeholder="Search products"
        placeholderTextColor={colors.textDisabled}
        underlineColorAndroid="transparent"
        style={styles.search}
      />
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => navigation.navigate('ProductDetails', { id: item.id })}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.meta}>{item.brand} • ${item.price}</Text>
          </Pressable>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: s(4) },
  search: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    borderRadius: s(2),
    paddingHorizontal: s(3),
    paddingVertical: s(3),
    marginBottom: s(3),
    color: colors.textPrimary,
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(3),
    marginBottom: s(2),
  },
  name: {
    color: colors.textPrimary,
    fontSize: 16,
    fontWeight: '600',
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
  meta: {
    color: colors.textSecondary,
    marginTop: s(1),
    fontFamily: Platform.select({ ios: 'System', android: 'Roboto', default: 'System' }),
  },
});