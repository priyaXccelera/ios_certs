import React, { ReactNode } from 'react';
import { StyleSheet, View, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type GlowCardProps = {
  children: ReactNode;
};

export function GlowCard({ children }: GlowCardProps) {
  return <View style={styles.card}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.primaryLight,
    ...Platform.select({
      ios: {
        shadowColor: colors.primary,
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.18,
        shadowRadius: 10,
      },
      android: { elevation: 8 },
      default: {},
    }),
  },
});
