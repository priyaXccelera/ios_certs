import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React, { useMemo, useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { formatMoney } from '../data/mockData';
import { RootStackParamList } from '../navigation';
import { AppointmentStatus } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const filters: Array<AppointmentStatus | 'all'> = ['all', 'confirmed', 'completed', 'noShow', 'cancelled'];

export default function AppointmentsScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Appointments'>>();
  const route = useRoute<RouteProp<RootStackParamList, 'Appointments'>>();
  const { appointments, services, staffMembers, locations } = useAppData();
  const [filter, setFilter] = useState<AppointmentStatus | 'all'>(route.params?.filter ?? 'all');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => appointments.filter((item) => {
    const service = services.find((svc) => svc.id === item.serviceId)?.name ?? '';
    const staff = staffMembers.find((member) => member.id === item.staffId)?.name ?? '';
    const location = locations.find((loc) => loc.id === item.locationId)?.name ?? '';
    const text = `${item.customerName} ${service} ${staff} ${location}`.toLowerCase();
    return (filter === 'all' || item.status === filter) && text.includes(search.toLowerCase());
  }).sort((a, b) => new Date(a.startIso).getTime() - new Date(b.startIso).getTime()), [appointments, filter, locations, search, services, staffMembers]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="All appointments" subtitle="Cancel, complete, or mark no-show" actionLabel="Book" onAction={() => navigation.navigate('Book')} />
      <View style={styles.content}>
        <TextInput value={search} onChangeText={setSearch} placeholder="Search appointments" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} returnKeyType="search" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
        <View style={styles.filterRow}>{filters.map((item) => <Chip key={item} label={item === 'all' ? 'All' : item} selected={filter === item} onPress={() => setFilter(item)} />)}</View>
        <FlatList
          style={styles.list}
          data={filtered}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => {
            const service = services.find((svc) => svc.id === item.serviceId);
            const staff = staffMembers.find((member) => member.id === item.staffId);
            const location = locations.find((loc) => loc.id === item.locationId);
            return (
              <View style={styles.cardWrap}>
                <Pressable onPress={() => navigation.navigate('AppointmentDetail', { id: item.id })} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={StyleSheet.absoluteFillObject} />
                <View pointerEvents="none" style={styles.cardContent}>
                  <View style={styles.cardTop}>
                    <AppText variant="subtitle" style={styles.cardTitle}>{item.customerName}</AppText>
                    <AppText variant="caption" style={styles.status}>{item.status}</AppText>
                  </View>
                  <AppText variant="body" style={styles.muted}>{service?.name ?? 'Service'} · {formatMoney(item.priceCents)}</AppText>
                  <AppText variant="caption">{new Date(item.startIso).toLocaleString()} · {staff?.name ?? 'Staff'} · {location?.name ?? 'Location'}</AppText>
                </View>
              </View>
            );
          }}
          ListEmptyComponent={<View style={styles.empty}><AppText variant="body">No appointments match this filter.</AppText><View style={styles.buttonGap} /><PrimaryButton label="Book one now" onPress={() => navigation.navigate('Book')} /></View>}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  content: { flex: 1, padding: s(4) },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  filterRow: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: s(2) },
  list: { flex: 1 },
  cardWrap: { minHeight: s(28), borderRadius: s(3), backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, overflow: 'hidden', ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 2 }, default: {} }) },
  cardContent: { flex: 1, padding: s(3), justifyContent: 'center' },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: s(2) },
  cardTitle: { flex: 1 },
  status: { color: colors.primary, fontFamily: 'Inter-SemiBold', fontWeight: '600' },
  muted: { color: colors.textSecondary, marginBottom: s(1) },
  separator: { height: s(2) },
  empty: { paddingTop: s(8), alignItems: 'center' },
  buttonGap: { height: s(3) },
});
