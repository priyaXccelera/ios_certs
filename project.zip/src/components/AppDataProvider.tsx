import React, { createContext, ReactNode, useContext, useMemo, useState } from 'react';
import { Appointment, AppointmentStatus, Location, ScheduleOverride, Service, StaffMember, WeeklySchedule, WaitlistEntry } from '../types';
import { appointments as appointmentSeed, locations as locationSeed, scheduleOverrides as overrideSeed, services as serviceSeed, staffMembers as staffSeed, waitlistEntries as waitlistSeed, weeklySchedules as scheduleSeed } from '../data/mockData';

interface AppDataContextValue {
  locations: Location[];
  services: Service[];
  staffMembers: StaffMember[];
  appointments: Appointment[];
  waitlistEntries: WaitlistEntry[];
  weeklySchedules: WeeklySchedule[];
  scheduleOverrides: ScheduleOverride[];
  addAppointment: (appointment: Appointment) => void;
  updateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  addWaitlistEntry: (entry: WaitlistEntry) => void;
  toggleWaitlistNotification: (id: string) => void;
  addLocation: (location: Location) => void;
  updateLocation: (location: Location) => void;
  addService: (service: Service) => void;
  updateService: (service: Service) => void;
  addStaffMember: (staff: StaffMember) => void;
  updateStaffMember: (staff: StaffMember) => void;
  updateWeeklySchedule: (schedule: WeeklySchedule) => void;
  addScheduleOverride: (override: ScheduleOverride) => void;
}

const AppDataContext = createContext<AppDataContextValue | undefined>(undefined);

interface AppDataProviderProps {
  children: ReactNode;
}

export function AppDataProvider({ children }: AppDataProviderProps) {
  const [locations, setLocations] = useState<Location[]>(locationSeed);
  const [services, setServices] = useState<Service[]>(serviceSeed);
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>(staffSeed);
  const [appointments, setAppointments] = useState<Appointment[]>(appointmentSeed);
  const [waitlistEntries, setWaitlistEntries] = useState<WaitlistEntry[]>(waitlistSeed);
  const [weeklySchedules, setWeeklySchedules] = useState<WeeklySchedule[]>(scheduleSeed);
  const [scheduleOverrides, setScheduleOverrides] = useState<ScheduleOverride[]>(overrideSeed);

  const value = useMemo<AppDataContextValue>(() => ({
    locations,
    services,
    staffMembers,
    appointments,
    waitlistEntries,
    weeklySchedules,
    scheduleOverrides,
    addAppointment: (appointment) => setAppointments((prev) => [appointment, ...prev]),
    updateAppointmentStatus: (id, status) => setAppointments((prev) => prev.map((item) => (item.id === id ? { ...item, status } : item))),
    addWaitlistEntry: (entry) => setWaitlistEntries((prev) => [entry, ...prev]),
    toggleWaitlistNotification: (id) => setWaitlistEntries((prev) => prev.map((item) => (item.id === id ? { ...item, notified: !item.notified } : item))),
    addLocation: (location) => setLocations((prev) => [location, ...prev]),
    updateLocation: (location) => setLocations((prev) => prev.map((item) => (item.id === location.id ? location : item))),
    addService: (service) => setServices((prev) => [service, ...prev]),
    updateService: (service) => setServices((prev) => prev.map((item) => (item.id === service.id ? service : item))),
    addStaffMember: (staff) => setStaffMembers((prev) => [staff, ...prev]),
    updateStaffMember: (staff) => setStaffMembers((prev) => prev.map((item) => (item.id === staff.id ? staff : item))),
    updateWeeklySchedule: (schedule) => setWeeklySchedules((prev) => prev.map((item) => (item.staffId === schedule.staffId ? schedule : item))),
    addScheduleOverride: (override) => setScheduleOverrides((prev) => [override, ...prev.filter((item) => !(item.staffId === override.staffId && item.date === override.date))]),
  }), [appointments, locations, scheduleOverrides, services, staffMembers, waitlistEntries, weeklySchedules]);

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
}

export function useAppData() {
  const value = useContext(AppDataContext);
  if (!value) {
    throw new Error('useAppData must be used inside AppDataProvider');
  }
  return value;
}
