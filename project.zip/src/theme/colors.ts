export const colors = {
  primary: '#007AFF',
  primaryDark: '#0051D5',
  primaryLight: '#EAF3FF',
  accent: '#FF9F0A',
  background: '#F5F5F7',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  border: '#D9D9DE',
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textDisabled: '#A1A1AA',
  textInverse: '#FFFFFF',
  success: '#34C759',
  warning: '#FFCC00',
  error: '#FF3B30',
  info: '#5AC8FA',
  shadowColor: '#000000',
} as const;

export type Colors = typeof colors;
