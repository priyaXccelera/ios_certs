# IOS Test Final — Screens & Navigation

## How to run
cd /home/ryzen/frontend_generator_backend/frontend_runs/run_6d10a094_20260722_120432/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Home | src/screens/HomeScreen.tsx | Hero landing screen with CTA, collaboration cards, and feature highlights. |
| Features | src/screens/FeaturesScreen.tsx | Feature cards and CTA to pricing. |
| Pricing | src/screens/PricingScreen.tsx | Plan comparison with selectable pricing cards. |
| Testimonials | src/screens/TestimonialsScreen.tsx | Swipeable testimonial cards with pagination. |
| Resources | src/screens/ResourcesScreen.tsx | Resource library list with selectable cards. |
| Company | src/screens/CompanyScreen.tsx | Mission statement and company values list. |
| Contact | src/screens/ContactScreen.tsx | Contact form with validation, submit, and reset actions. |
| Login | src/screens/LoginScreen.tsx | Email/password login with forgot password and Google sign-in. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen for unknown routes. |

## Navigation map
- Home -> Pricing (tap "Get Started Free" or "Explore Pricing")
- Features -> Pricing (tap "View Pricing")
- Testimonials -> Contact (tap "Talk to Sales")
- Drawer items -> respective screens (tap drawer link)

## Shared components
- src/components/SectionHeader.tsx — Section title + subtitle block.
- src/components/PrimaryButton.tsx — Gradient CTA button with press scaling.
- src/components/SecondaryButton.tsx — Secondary outline-styled button.
- src/components/OutlineButton.tsx — Neutral outline button for OAuth actions.
- src/components/InlineLink.tsx — Inline text link.
- src/components/HeaderBar.tsx — Sticky header with logo text and menu button.
- src/components/FeatureCard.tsx — Feature highlight card.
- src/components/PricingCard.tsx — Plan card with features and CTA.
- src/components/TestimonialCard.tsx — Testimonial card with avatar and rating.
- src/components/CollaborationCard.tsx — Collaboration highlight card with image placeholder.
- src/components/InfoCard.tsx — Simple info card for company values.
- src/components/PaginationDots.tsx — Pagination indicator dots.
- src/components/StatCard.tsx — Compact stat highlight card.
- src/components/Chip.tsx — Accent chip label.
- src/components/GlowCard.tsx — Elevated glowing card container.
- src/components/DrawerLink.tsx — Drawer navigation link row.
- src/components/InputField.tsx — Labeled TextInput with error handling.
- src/components/Divider.tsx — Hairline divider.
- src/components/ScreenContainer.tsx — Base background wrapper.
- src/components/ScreenTitle.tsx — Screen heading + subtitle.
- src/components/FeatureListItem.tsx — Row with check icon.
- src/components/HighlightBadge.tsx — Highlight badge label.
- src/components/EmptyState.tsx — Empty state block.

## Design tokens
primary, primaryDark, primaryLight, accent, background, surface, card, border, textPrimary, textSecondary, textDisabled, textInverse, success, warning, error, info, shadowColor.
