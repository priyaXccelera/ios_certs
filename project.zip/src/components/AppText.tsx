import React from 'react';
import { Platform, StyleProp, StyleSheet, Text, TextProps, TextStyle } from 'react-native';
import { colors } from '../theme/colors';

type AppTextVariant = 'title' | 'subtitle' | 'body' | 'caption' | 'label';

interface AppTextProps extends TextProps {
  variant?: AppTextVariant;
  style?: StyleProp<TextStyle>;
}

export function AppText({ variant = 'body', style, children, ...props }: AppTextProps) {
  return (
    <Text {...props} style={[styles.base, styles[variant], style]}>
      {children}
    </Text>
  );
}

const styles = StyleSheet.create({
  base: {
    fontFamily: 'Inter-Regular',
    color: colors.textPrimary,
    letterSpacing: 0.2,
  },
  title: {
    fontSize: 28,
    lineHeight: 34,
    fontWeight: '700',
    letterSpacing: -0.5,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    fontSize: 20,
    lineHeight: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
    fontFamily: 'Inter-Bold',
  },
  body: {
    fontSize: 15,
    lineHeight: 21,
    fontWeight: '400',
  },
  caption: {
    fontSize: 12,
    lineHeight: 17,
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: Platform.select({ ios: 'Inter-Medium', android: 'Inter-Medium', default: 'Inter-Medium' }),
  },
  label: {
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
    color: colors.textSecondary,
    letterSpacing: 1.2,
    fontFamily: 'Inter-SemiBold',
  },
});
