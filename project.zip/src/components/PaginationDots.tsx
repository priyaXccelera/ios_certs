import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type PaginationDotsProps = {
  total: number;
  activeIndex: number;
};

export function PaginationDots({ total, activeIndex }: PaginationDotsProps) {
  return (
    <View style={styles.container}>
      {Array.from({ length: total }).map((_, index) => (
        <View
          key={`dot-${index}`}
          style={[styles.dot, index === activeIndex && styles.activeDot]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: s(3),
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.border,
    marginHorizontal: s(1),
  },
  activeDot: {
    backgroundColor: colors.primary,
    width: s(4),
  },
});
