import { StatusBar } from 'expo-status-bar';
import React, { useMemo, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useNavigation } from '@react-navigation/native';
import { AppText } from '../components/AppText';
import { Chip } from '../components/Chip';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { useAppData } from '../components/AppDataProvider';
import { formatMoney } from '../data/mockData';
import { RootStackParamList } from '../navigation';
import { Appointment, DayKey, StaffMember, TimeBlock } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const dayNames: DayKey[] = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const dateOptions = Array.from({ length: 8 }).map((_, index) => {
  const date = new Date();
  date.setDate(date.getDate() + index);
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day = `${date.getDate()}`.padStart(2, '0');
  return `${year}-${month}-${day}`;
});

function minutesFromTime(time: string) {
  const [hour, minute] = time.split(':').map(Number);
  return hour * 60 + minute;
}

function timeFromMinutes(minutes: number) {
  const hour = Math.floor(minutes / 60).toString().padStart(2, '0');
  const minute = (minutes % 60).toString().padStart(2, '0');
  return `${hour}:${minute}`;
}

function isoFromLocalDateTime(date: string, time: string) {
  return new Date(`${date}T${time}:00`).toISOString();
}

function formatLocalDateLabel(date: string) {
  const [year, month, day] = date.split('-').map(Number);
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(year, month - 1, day, 12)));
}

function formatTimeZoneLabel(timezone: string) {
  return timezone.replace(/_/g, ' ');
}

function overlaps(start: number, end: number, busyStart: number, busyEnd: number) {
  return start < busyEnd && end > busyStart;
}

export default function BookScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Book'>>();
  const { locations, services, staffMembers, appointments, weeklySchedules, scheduleOverrides, addAppointment, addWaitlistEntry } = useAppData();
  const [locationId, setLocationId] = useState(locations[0]?.id ?? '');
  const [serviceId, setServiceId] = useState(services[0]?.id ?? '');
  const [staffId, setStaffId] = useState('any');
  const [date, setDate] = useState(dateOptions[1] ?? dateOptions[0]);
  const [time, setTime] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const service = services.find((item) => item.id === serviceId);
  const location = locations.find((item) => item.id === locationId);

  const eligibleStaff = useMemo(() => staffMembers.filter((staff) => staff.locationId === locationId && staff.serviceIds.includes(serviceId)), [locationId, serviceId, staffMembers]);

  const availableSlots = useMemo(() => {
    if (!service) return [];
    const selectedStaff = staffId === 'any' ? eligibleStaff : eligibleStaff.filter((staff) => staff.id === staffId);
    const slots = new Map<string, StaffMember>();
    selectedStaff.forEach((staff) => {
      const override = scheduleOverrides.find((item) => item.staffId === staff.id && item.date === date);
      const dayName = dayNames[new Date(`${date}T12:00:00`).getDay()];
      const blocks: TimeBlock[] = override ? override.blocks : (weeklySchedules.find((item) => item.staffId === staff.id)?.days[dayName] ?? []);
      blocks.forEach((block) => {
        for (let start = minutesFromTime(block.start); start + service.durationMinutes <= minutesFromTime(block.end); start += 15) {
          const end = start + service.durationMinutes;
          const startIso = isoFromLocalDateTime(date, timeFromMinutes(start));
          if (new Date(startIso).getTime() <= Date.now()) continue;
          const conflict = appointments.some((apt) => apt.staffId === staff.id && apt.status === 'confirmed' && overlaps(start, end, new Date(apt.startIso).getHours() * 60 + new Date(apt.startIso).getMinutes(), new Date(apt.endIso).getHours() * 60 + new Date(apt.endIso).getMinutes()) && apt.startIso.slice(0, 10) === startIso.slice(0, 10));
          if (!conflict && !slots.has(timeFromMinutes(start))) slots.set(timeFromMinutes(start), staff);
        }
      });
    });
    return Array.from(slots.entries()).map(([slotTime, staff]) => ({ time: slotTime, staff })).sort((a, b) => a.time.localeCompare(b.time));
  }, [appointments, date, eligibleStaff, scheduleOverrides, service, staffId, weeklySchedules]);

  const selectedSlot = availableSlots.find((item) => item.time === time);

  const confirm = () => {
    if (!service || !location || !selectedSlot) return;
    const startIso = isoFromLocalDateTime(date, selectedSlot.time);
    const endIso = new Date(new Date(startIso).getTime() + service.durationMinutes * 60000).toISOString();
    const appointment: Appointment = {
      id: `apt-${Date.now()}`,
      customerName: customerName.trim() || 'Walk-in Customer',
      customerEmail: customerEmail.trim() || 'customer@example.com',
      locationId,
      serviceId,
      staffId: selectedSlot.staff.id,
      startIso,
      endIso,
      status: 'confirmed',
      priceCents: service.priceCents,
    };
    addAppointment(appointment);
    navigation.navigate('Confirmation', { appointmentId: appointment.id });
  };

  const joinWaitlist = () => {
    if (!service || !location) return;
    addWaitlistEntry({ id: `wait-${Date.now()}`, customerName: customerName.trim() || 'Waitlist Guest', customerEmail: customerEmail.trim() || 'guest@example.com', locationId, serviceId, staffId: staffId === 'any' ? undefined : staffId, date, createdAtIso: new Date().toISOString(), notified: false });
    navigation.navigate('Waitlist');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Browse & book" subtitle="Pick a location, service, staff, day, and time" />
      <KeyboardAvoidingView style={styles.keyboard} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}>
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <AppText variant="label">LOCATION</AppText>
          <View style={styles.wrap}>{locations.map((item) => <Chip key={item.id} label={`${item.name} · ${item.city}`} selected={item.id === locationId} onPress={() => { setLocationId(item.id); setStaffId('any'); setTime(''); }} />)}</View>
          <AppText variant="label">SERVICE</AppText>
          <View style={styles.wrap}>{services.map((item) => <Chip key={item.id} label={`${item.name} · ${formatMoney(item.priceCents)}`} selected={item.id === serviceId} onPress={() => { setServiceId(item.id); setStaffId('any'); setTime(''); }} />)}</View>
          <AppText variant="label">STAFF</AppText>
          <View style={styles.wrap}><Chip label="Anyone available" selected={staffId === 'any'} onPress={() => { setStaffId('any'); setTime(''); }} />{eligibleStaff.map((item) => <Chip key={item.id} label={item.name} selected={staffId === item.id} onPress={() => { setStaffId(item.id); setTime(''); }} />)}</View>
          <AppText variant="label">DAY</AppText>
          <View style={styles.wrap}>{dateOptions.map((item) => <Chip key={item} label={formatLocalDateLabel(item)} selected={date === item} onPress={() => { setDate(item); setTime(''); }} />)}</View>
          <AppText variant="label">OPEN TIMES {location ? `· local time in ${formatTimeZoneLabel(location.timezone)}` : ''}</AppText>
          <View style={styles.wrap}>{availableSlots.map((item) => <Chip key={`${item.time}-${item.staff.id}`} label={`${item.time} · ${item.staff.name.split(' ')[0]}`} selected={time === item.time} onPress={() => setTime(item.time)} />)}</View>
          {availableSlots.length === 0 ? <AppText variant="body" style={styles.empty}>No open times for this choice. Add this customer to the waitlist for the day.</AppText> : null}
          <View style={styles.formCard}>
            <TextInput value={customerName} onChangeText={setCustomerName} placeholder="Customer name" placeholderTextColor={colors.textDisabled} autoCapitalize="words" autoCorrect={false} returnKeyType="next" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <TextInput value={customerEmail} onChangeText={setCustomerEmail} placeholder="Customer email" placeholderTextColor={colors.textDisabled} autoCapitalize="none" autoCorrect={false} keyboardType="email-address" returnKeyType="done" underlineColorAndroid="transparent" selectionColor={colors.primary} style={styles.input} />
            <PrimaryButton label="Confirm appointment" onPress={confirm} disabled={!selectedSlot} />
            <View style={styles.buttonGap} />
            <PrimaryButton label="Add to waitlist" onPress={joinWaitlist} variant="secondary" />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  keyboard: { flex: 1 },
  scroll: { flex: 1 },
  content: { padding: s(4), paddingBottom: s(8) },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', marginTop: s(2), marginBottom: s(4) },
  empty: { color: colors.warning, marginBottom: s(4) },
  formCard: { backgroundColor: colors.surface, borderRadius: s(3), padding: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  input: { minHeight: s(12), borderRadius: s(2), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, paddingHorizontal: s(3), marginBottom: s(3), color: colors.textPrimary, fontFamily: 'Inter-Regular', fontSize: 15, lineHeight: 21, fontWeight: '400', backgroundColor: colors.surface },
  buttonGap: { height: s(2) },
});
