import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { FlatList, Platform, Pressable, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText } from '../components/AppText';
import { HeaderBar } from '../components/HeaderBar';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

type ManageTarget = 'Locations' | 'Services' | 'Staff' | 'StaffHours';
interface ManageItem { id: string; title: string; subtitle: string; icon: keyof typeof Ionicons.glyphMap; target: ManageTarget }

const items: ManageItem[] = [
  { id: 'manage-locations', title: 'Locations', subtitle: 'Add or edit business locations', icon: 'business', target: 'Locations' },
  { id: 'manage-services', title: 'Services', subtitle: 'Set prices, durations, and trained staff', icon: 'pricetag', target: 'Services' },
  { id: 'manage-staff', title: 'Staff members', subtitle: 'Add or edit staff and services', icon: 'people', target: 'Staff' },
  { id: 'manage-hours', title: 'Staff hours', subtitle: 'Weekly blocks and day-specific overrides', icon: 'time', target: 'StaffHours' },
];

export default function ManageScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Manage'>>();
  const goTo = (item: ManageItem) => {
    if (item.target === 'StaffHours') navigation.navigate('StaffHours', {});
    else navigation.navigate(item.target);
  };
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />
      <HeaderBar title="Manage" subtitle="Locations, services, staff, and hours" />
      <FlatList
        style={styles.list}
        contentContainerStyle={styles.content}
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Pressable onPress={() => goTo(item)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && styles.pressed]}>
            <View style={styles.icon}><Ionicons name={item.icon} size={s(6)} color={colors.primary} /></View>
            <View style={styles.textArea}>
              <AppText variant="subtitle">{item.title}</AppText>
              <AppText variant="body" style={styles.subtitle}>{item.subtitle}</AppText>
            </View>
            <Ionicons name="chevron-forward" size={s(5)} color={colors.textDisabled} />
          </Pressable>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}) },
  list: { flex: 1 },
  content: { padding: s(4) },
  card: { minHeight: s(24), flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: s(3), padding: s(4), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border },
  icon: { width: s(12), height: s(12), borderRadius: s(6), backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginRight: s(3) },
  textArea: { flex: 1 },
  subtitle: { color: colors.textSecondary, marginTop: s(1) },
  separator: { height: s(3) },
  pressed: { opacity: 0.7 },
});
