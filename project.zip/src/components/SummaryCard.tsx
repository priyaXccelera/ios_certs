import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { AppText } from './AppText';

interface SummaryCardProps {
  label: string;
  value: string;
  icon: keyof typeof Ionicons.glyphMap;
  tone?: 'primary' | 'success' | 'warning' | 'error';
}

export function SummaryCard({ label, value, icon, tone = 'primary' }: SummaryCardProps) {
  return (
    <View style={styles.card}>
      <View style={[styles.iconWrap, styles[tone]]}>
        <Ionicons name={icon} size={s(5)} color={colors.textInverse} />
      </View>
      <AppText variant="title" style={styles.value}>{value}</AppText>
      <AppText variant="caption" style={styles.label}>{label}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minHeight: s(32),
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(2) }, shadowOpacity: 0.1, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  iconWrap: {
    width: s(9),
    height: s(9),
    borderRadius: s(4),
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(3),
  },
  primary: {
    backgroundColor: colors.primary,
  },
  success: {
    backgroundColor: colors.success,
  },
  warning: {
    backgroundColor: colors.warning,
  },
  error: {
    backgroundColor: colors.error,
  },
  value: {
    fontSize: 24,
    lineHeight: 29,
  },
  label: {
    marginTop: s(1),
  },
});
