import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { initialCartItems, products } from '../data/mockData';
import { CartItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function CartScreen() {
  const [items, setItems] = useState<CartItem[]>(initialCartItems);
  const [discountApplied, setDiscountApplied] = useState(false);

  const rows = items.map((item) => ({ item, product: products.find((product) => product.id === item.productId) ?? products[0] }));
  const subtotal = rows.reduce((sum, row) => sum + row.product.price * row.item.quantity, 0);
  const shipping = subtotal > 150 || subtotal === 0 ? 0 : 12;
  const discount = discountApplied ? Math.round(subtotal * 0.12) : 0;
  const total = subtotal + shipping - discount;

  const updateQty = (id: string, delta: number) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item)));
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const checkout = () => {
    if (items.length === 0) {
      Alert.alert('Cart is empty', 'Add products before checkout.');
      return;
    }
    setItems([]);
    setDiscountApplied(false);
    Alert.alert('Purchase complete', `Your mock order total was $${total}.`);
  };

  const renderRow = ({ item }: { item: { item: CartItem; product: typeof products[number] } }) => (
    <View style={styles.rowCard}>
      <View style={styles.imageBox}>
        <Ionicons name="cube-outline" size={s(8)} color={colors.primary} />
      </View>
      <View style={styles.rowText}>
        <Text style={styles.brand}>{item.product.brand}</Text>
        <Text style={styles.name}>{item.product.name}</Text>
        <Text style={styles.meta}>{item.item.color} · {item.item.size}</Text>
        <Text style={styles.price}>${item.product.price * item.item.quantity}</Text>
      </View>
      <View style={styles.actions}>
        <Pressable onPress={() => removeItem(item.item.id)} hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }} android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }} style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
          <Ionicons name="trash-outline" size={s(5)} color={colors.error} />
        </Pressable>
        <View style={styles.qtyRow}>
          <Pressable onPress={() => updateQty(item.item.id, -1)} android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }} style={({ pressed }) => [styles.qtyButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
            <Text style={styles.qtySign}>−</Text>
          </Pressable>
          <Text style={styles.qtyText}>{item.item.quantity}</Text>
          <Pressable onPress={() => updateQty(item.item.id, 1)} android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }} style={({ pressed }) => [styles.qtyButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
            <Text style={styles.qtySign}>+</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );

  const summary = useMemo(() => (
    <View style={styles.summaryCard}>
      <Pressable onPress={() => setDiscountApplied((prev) => !prev)} android_ripple={{ color: 'rgba(0,0,0,0.08)' }} style={({ pressed }) => [styles.discountButton, discountApplied && styles.discountActive, pressed && Platform.OS === 'ios' && styles.pressed]}>
        <Text style={[styles.discountText, discountApplied && styles.discountTextActive]}>{discountApplied ? 'Demo discount applied' : 'Apply demo discount'}</Text>
      </Pressable>
      <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Subtotal</Text><Text style={styles.summaryValue}>${subtotal}</Text></View>
      <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Shipping estimate</Text><Text style={styles.summaryValue}>${shipping}</Text></View>
      <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Discount</Text><Text style={styles.summaryValue}>−${discount}</Text></View>
      <View style={styles.totalRow}><Text style={styles.totalLabel}>Order total</Text><Text style={styles.totalValue}>${total}</Text></View>
      <Pressable onPress={checkout} android_ripple={{ color: 'rgba(0,0,0,0.12)' }} style={({ pressed }) => [styles.checkoutButton, pressed && Platform.OS === 'ios' && styles.pressed]}>
        <Text style={styles.checkoutText}>Mock Checkout</Text>
      </Pressable>
    </View>
  ), [discount, discountApplied, shipping, subtotal, total, items.length]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <HeaderBar title="Cart" subtitle={`${items.length} selected products`} />
      <FlatList
        data={rows}
        keyExtractor={(row) => row.item.id}
        renderItem={renderRow}
        ListEmptyComponent={<Text style={styles.emptyText}>Your cart is ready for premium finds.</Text>}
        ListFooterComponent={summary}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background, ...(Platform.OS === 'web' ? { overflow: 'hidden' as never, maxHeight: '100vh' as never } : {}) },
  listContent: { paddingHorizontal: s(4), paddingBottom: s(8) },
  rowCard: { minHeight: s(32), borderRadius: s(4), backgroundColor: colors.card, padding: s(3), flexDirection: 'row', ...Platform.select({ ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) }, android: { elevation: 3 }, default: {} }) },
  separator: { height: s(3) },
  imageBox: { width: s(24), height: s(24), borderRadius: s(3), backgroundColor: colors.primaryLight, alignItems: 'center', justifyContent: 'center', marginRight: s(3) },
  rowText: { flex: 1 },
  brand: { fontFamily: 'Inter-SemiBold', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 1.2, textTransform: 'uppercase' },
  name: { marginTop: s(1), fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', color: colors.textPrimary, letterSpacing: 0.2 },
  meta: { marginTop: s(1), fontFamily: 'Inter-Regular', fontSize: s(3), lineHeight: s(3) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  price: { marginTop: s(2), fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  actions: { alignItems: 'flex-end', justifyContent: 'space-between' },
  iconButton: { width: s(9), height: s(9), borderRadius: s(5), alignItems: 'center', justifyContent: 'center' },
  qtyRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.background, borderRadius: s(5), padding: s(1) },
  qtyButton: { width: s(8), height: s(8), borderRadius: s(4), backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  qtySign: { fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.primary, letterSpacing: -0.5 },
  qtyText: { minWidth: s(8), textAlign: 'center', fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.textPrimary, letterSpacing: 0.2 },
  summaryCard: { marginTop: s(5), borderRadius: s(4), backgroundColor: colors.card, padding: s(4) },
  discountButton: { minHeight: s(12), borderRadius: s(3), borderWidth: StyleSheet.hairlineWidth, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', marginBottom: s(4) },
  discountActive: { backgroundColor: colors.success, borderColor: colors.success },
  discountText: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.primary, letterSpacing: 0.2 },
  discountTextActive: { color: colors.textInverse },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: s(3) },
  summaryLabel: { fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  summaryValue: { fontFamily: 'Inter-SemiBold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '600', color: colors.textPrimary, letterSpacing: 0.2 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: s(3), borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border },
  totalLabel: { fontFamily: 'Inter-Bold', fontSize: s(5), lineHeight: s(5) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  totalValue: { fontFamily: 'Inter-Bold', fontSize: s(6), lineHeight: s(6) * 1.2, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 },
  checkoutButton: { minHeight: s(14), borderRadius: s(4), backgroundColor: colors.textPrimary, alignItems: 'center', justifyContent: 'center', marginTop: s(4) },
  checkoutText: { fontFamily: 'Inter-Bold', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '700', color: colors.textInverse, letterSpacing: 0.2 },
  emptyText: { textAlign: 'center', marginVertical: s(8), fontFamily: 'Inter-Regular', fontSize: s(4), lineHeight: s(4) * 1.4, fontWeight: '400', color: colors.textSecondary, letterSpacing: 0.2 },
  pressed: { opacity: 0.72 },
});
