import React, { useState } from 'react';
import { FlatList, NativeScrollEvent, NativeSyntheticEvent, Platform, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useNavigation } from '@react-navigation/native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import { TestimonialCard } from '../components/TestimonialCard';
import { PaginationDots } from '../components/PaginationDots';
import { SectionHeader } from '../components/SectionHeader';
import { PrimaryButton } from '../components/PrimaryButton';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { testimonials } from '../data/mockData';
import { DrawerParamList } from '../navigation';

export default function TestimonialsScreen() {
  const navigation = useNavigation<DrawerNavigationProp<DrawerParamList, 'Testimonials'>>();
  const [activeIndex, setActiveIndex] = useState(0);
  const cardWidth = s(70) + s(4);

  const handleMomentumScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const index = Math.round(event.nativeEvent.contentOffset.x / cardWidth);
    setActiveIndex(Math.min(Math.max(index, 0), testimonials.length - 1));
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <SectionHeader title="Testimonials" subtitle="See why leaders trust Circle." />
      </View>
      <FlatList
        data={testimonials}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <TestimonialCard item={item} />}
        horizontal
        showsHorizontalScrollIndicator={false}
        pagingEnabled
        snapToInterval={cardWidth}
        decelerationRate="fast"
        directionalLockEnabled
        onMomentumScrollEnd={handleMomentumScrollEnd}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
        contentContainerStyle={styles.listContent}
        style={styles.list}
      />
      <PaginationDots total={testimonials.length} activeIndex={activeIndex} />
      <View style={styles.footer}>
        <Text style={styles.footerText}>Join teams delivering premium customer experiences.</Text>
        <PrimaryButton label="Talk to Sales" onPress={() => navigation.navigate('Contact')} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    paddingHorizontal: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as const, maxHeight: '100vh' as any } : {}),
  },
  header: {
    paddingTop: s(5),
    marginBottom: s(3),
  },
  list: {
    height: s(64),
  },
  listContent: {
    paddingBottom: s(2),
  },
  footer: {
    marginTop: s(5),
    paddingBottom: s(6),
  },
  footerText: {
    marginBottom: s(3),
    fontSize: 13,
    fontWeight: '400',
    lineHeight: 13 * 1.4,
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
});
