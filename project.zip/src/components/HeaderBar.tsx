import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  actionIcon?: keyof typeof Ionicons.glyphMap;
  onAction?: () => void;
}

export function HeaderBar({ title, subtitle, onBack, actionIcon, onAction }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.leftArea}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Ionicons name="chevron-back" size={s(6)} color={colors.primary} />
          </Pressable>
        ) : null}
        <View style={styles.titleWrap}>
          <Text style={styles.title}>{title}</Text>
          {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
        </View>
      </View>
      {actionIcon && onAction ? (
        <Pressable
          onPress={onAction}
          hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
          style={({ pressed }) => [styles.iconButton, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <Ionicons name={actionIcon} size={s(6)} color={colors.primary} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: s(4),
    paddingTop: s(2),
    paddingBottom: s(3),
    backgroundColor: colors.background,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftArea: {
    flex: 1,
    minHeight: s(14),
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: {
    opacity: 0.7,
  },
  titleWrap: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: s(8),
    lineHeight: s(8) * 1.2,
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
  },
  subtitle: {
    marginTop: s(1),
    fontFamily: 'Inter-Regular',
    fontSize: s(4),
    lineHeight: s(4) * 1.4,
    fontWeight: '400',
    color: colors.textSecondary,
    letterSpacing: 0.2,
  },
});
