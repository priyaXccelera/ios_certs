import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, StyleSheet, View } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { AppText } from './AppText';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  actionLabel?: string;
  onAction?: () => void;
}

export function HeaderBar({ title, subtitle, onBack, actionLabel, onAction }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.leftArea}>
        {onBack ? (
          <Pressable
            onPress={onBack}
            hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
            style={({ pressed }) => [styles.backButton, pressed && Platform.OS === 'ios' && styles.pressed]}
          >
            <Ionicons name="chevron-back" size={s(6)} color={colors.primary} />
          </Pressable>
        ) : null}
        <View style={styles.titleArea}>
          <AppText variant="subtitle" style={styles.title}>{title}</AppText>
          {subtitle ? <AppText variant="caption" style={styles.subtitle}>{subtitle}</AppText> : null}
        </View>
      </View>
      {actionLabel && onAction ? (
        <Pressable
          onPress={onAction}
          android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: false }}
          style={({ pressed }) => [styles.action, pressed && Platform.OS === 'ios' && styles.pressed]}
        >
          <AppText variant="caption" style={styles.actionText}>{actionLabel}</AppText>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    minHeight: s(16),
    paddingHorizontal: s(4),
    paddingVertical: s(3),
    backgroundColor: colors.surface,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...Platform.select({
      ios: { shadowColor: colors.shadowColor, shadowOffset: { width: 0, height: s(1) }, shadowOpacity: 0.08, shadowRadius: s(2) },
      android: { elevation: 4 },
      default: {},
    }),
  },
  leftArea: {
    flex: 1,
    minHeight: s(10),
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    width: s(10),
    height: s(10),
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(1),
  },
  titleArea: {
    flex: 1,
  },
  title: {
    color: colors.textPrimary,
  },
  subtitle: {
    marginTop: s(1),
  },
  action: {
    minHeight: s(9),
    paddingHorizontal: s(3),
    borderRadius: s(2),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionText: {
    color: colors.primaryDark,
    fontFamily: 'Inter-SemiBold',
    fontWeight: '600',
  },
  pressed: {
    opacity: 0.7,
  },
});
