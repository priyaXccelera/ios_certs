import { CollaborationCard, CompanyValue, Feature, Plan, ResourceItem, Testimonial } from '../types';

export const collaborationCards: CollaborationCard[] = [
  { id: 'collab-1', title: 'Unified Workspace', subtitle: 'Connect teams and customers fast.' },
  { id: 'collab-2', title: 'Realtime Insights', subtitle: 'Monitor engagement in seconds.' },
  { id: 'collab-3', title: 'Secure Sharing', subtitle: 'Enterprise-grade controls.' },
  { id: 'collab-4', title: 'Automated Follow-ups', subtitle: 'Never miss a response.' },
  { id: 'collab-5', title: 'Global Scale', subtitle: 'Launch campaigns worldwide.' },
];

export const features: Feature[] = [
  {
    id: 'feature-analytics',
    title: 'Analytics',
    description: 'Reporting and engagement metrics that show what matters most.',
    icon: 'insights',
  },
  {
    id: 'feature-community',
    title: 'Community',
    description: 'Build stronger customer relationships with two-way engagement.',
    icon: 'groups',
  },
  {
    id: 'feature-automation',
    title: 'Automation',
    description: 'Workflow automation that keeps every team aligned.',
    icon: 'auto-awesome',
  },
];

export const testimonials: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Lena Patel',
    company: 'Orbit Finance',
    rating: 5,
    message: 'Circle transformed the way we track engagement. Reports are instant and the support team is unmatched.',
  },
  {
    id: 'test-2',
    name: 'Marco Ruiz',
    company: 'Signal Growth',
    rating: 4,
    message: 'Our team scaled to new markets with confidence. The automation saves hours every week.',
  },
  {
    id: 'test-3',
    name: 'Aisha Khan',
    company: 'Northbridge AI',
    rating: 5,
    message: 'Beautiful UI, fast performance, and analytics that are easy to act on.',
  },
  {
    id: 'test-4',
    name: 'Owen Brooks',
    company: 'Harbor Labs',
    rating: 5,
    message: 'Our engagement rate jumped by 38% after switching to Circle.',
  },
];

export const plans: Plan[] = [
  {
    id: 'plan-starter',
    name: 'Starter',
    price: 'Free',
    highlight: false,
    features: ['Core analytics dashboard', 'Community templates', 'Email support'],
  },
  {
    id: 'plan-pro',
    name: 'Professional',
    price: '$29/month',
    highlight: true,
    features: ['Advanced automation', 'Custom reporting', 'Priority support', 'Team workspaces'],
  },
  {
    id: 'plan-enterprise',
    name: 'Enterprise',
    price: 'Custom',
    highlight: false,
    features: ['Dedicated success team', 'SLA & compliance', 'Unlimited integrations'],
  },
];

export const resources: ResourceItem[] = [
  {
    id: 'resource-1',
    title: 'Engagement Playbook',
    category: 'Guides',
    summary: 'Step-by-step tactics for improving customer response rates.',
  },
  {
    id: 'resource-2',
    title: 'AI Metrics Dashboard',
    category: 'Reports',
    summary: 'Understand the KPIs that drive predictable growth.',
  },
  {
    id: 'resource-3',
    title: 'Automation Blueprint',
    category: 'Templates',
    summary: 'Ready-to-use workflows for sales, onboarding, and support.',
  },
];

export const companyValues: CompanyValue[] = [
  { id: 'value-1', title: 'Trust First', detail: 'Security and compliance are built into every workflow.' },
  { id: 'value-2', title: 'Fast by Design', detail: 'Lightning quick performance across devices and teams.' },
  { id: 'value-3', title: 'Customer Obsessed', detail: 'We build features that remove friction and unlock growth.' },
];
