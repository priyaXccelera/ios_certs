# SUKHMEET ios — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_ef1cbc53_20260724_094910/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Discover | src/screens/DiscoverScreen.tsx | Featured banner, search, category filtering, trending products, recommendations and product navigation. |
| ProductDetails | src/screens/ProductDetailsScreen.tsx | Swipeable mock gallery, product overview, price, ratings, colors, sizes, specifications, related items, save and add-to-cart actions. |
| Cart | src/screens/CartScreen.tsx | Selected products, quantity controls, remove actions, discount simulation, shipping estimate and mock checkout. |
| Wishlist | src/screens/WishlistScreen.tsx | Saved products with search, remove, move-to-cart and product-detail navigation. |
| Orders | src/screens/OrdersScreen.tsx | Mock purchase history, expandable order details, delivery progress, payment summary and buy-again workflow. |
| Profile | src/screens/ProfileScreen.tsx | Customer card, saved addresses, appearance, notification and privacy preferences, and app information. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen with go-back action. |

## Navigation map
- MainTabs -> Discover (default tab on app launch)
- Discover -> ProductDetails (tap any product card in trending or recommendations)
- ProductDetails -> ProductDetails (tap a related item card)
- ProductDetails -> MainTabs/Cart (tap Add to Cart after selecting options)
- MainTabs tab bar -> Wishlist (tap Wishlist tab)
- Wishlist -> ProductDetails (tap a saved product row)
- MainTabs tab bar -> Cart (tap Cart tab)
- Cart -> checkout completion alert (tap Mock Checkout)
- MainTabs tab bar -> Orders (tap Orders tab)
- Orders -> order expansion (tap order card)
- Orders -> new local order (tap Buy Again)
- MainTabs tab bar -> Profile (tap Profile tab)
- Profile -> preference update alerts (toggle settings or tap Application details)
- ProductDetails/NotFound -> previous screen (tap back controls)

## Shared components
- src/components/HeaderBar.tsx — Large iOS-inspired title bar with optional subtitle, back chevron and right action icon.
- src/components/ProductCard.tsx — Reusable tappable product card with image placeholder, brand, price, rating and independent wishlist button using the absolute-fill split pattern.
- src/components/SearchField.tsx — Rounded native search input with icon, placeholder styling and Android underline suppression.

## Design tokens
- primary: #007AFF
- primaryDark: #0051D5
- primaryLight: #EAF3FF
- accent: #FF9F0A
- background: #F5F5F7
- surface: #FFFFFF
- card: #FFFFFF
- border: #D9D9DE
- textPrimary: #111827
- textSecondary: #6B7280
- textDisabled: #A1A1AA
- textInverse: #FFFFFF
- success: #34C759
- warning: #FFCC00
- error: #FF3B30
- info: #5AC8FA
- shadowColor: #000000
